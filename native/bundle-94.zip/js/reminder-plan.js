/* СВЯЗКА НАПОМИНАНИЙ С ПРИЛОЖЕНИЕМ.

   Три слоя, и у каждого своё дело:

     core/reminders.js      — фасад над плагином: разрешения, канал,
                              постановка и снятие. Про моменты и окна не
                              знает ничего.
     core/reminder-rules.js — чистые правила: что звонит и когда. Без
                              браузера, под тестами.
     этот файл              — связка: берёт состояние приложения, спрашивает
                              правила и отдаёт решение фасаду.

   ДВА ИСТОЧНИКА НАПОМИНАНИЙ.
   1. Моменты дня («Архитектор метавселенной») — приходят с сервера со
      своим временем, по девять на день.
   2. Окно возможностей («Наблюдатель метавселенной») — считается само:
      последний прыжок плюс 3 часа 33 минуты.

   В браузере весь модуль молчит и возвращает false. Системных напоминаний
   в браузере не бывает в принципе: страница закрыта — таймеры мертвы, а
   разбудить себя по часам вкладка не может. Это не чинится кодом, только
   установкой приложения. */

import { ensureReady, scheduleReminders, cancelKeys, onReminderAction, isNative } from './core/reminders.js';
import {
    momentPlan, windowPlan, normalizeQuiet as normalize, KEY_WINDOW
} from './core/reminder-rules.js';
import { state, t } from './store.js';
import { getMeta, setMeta } from './db.js';
import { CONFIG } from './views/space/config.js';

/* ТИХИЙ ЧАС.

   Промежуток, когда приложение не беспокоит: не звонит, не вибрирует,
   не зажигает экран. Границы задаёт человек в профиле — кнопка «Тихий
   час». Раньше они были зашиты в код, и это было неправильно: время сна
   у каждого своё, и менять его правкой исходников нельзя.

   Начальные границы берутся из dailyWindow раздела — с 21 до 6. Эти
   цифры лежали в config.js с самого начала как рабочее время раздела, и
   до недавнего они ни разу не применялись. Пусть они и будут тем, что
   человек увидит в настройке до первой своей правки.

   Хранится настройка на устройстве, рядом с языком: это свойство
   телефона, а не учётной записи. На планшете человек вправе спать в
   другое время. */
const QUIET_KEY = 'quietHours';
const двеЦифры = n => String(n).padStart(2, '0') + ':00';

export const QUIET_DEFAULT = Object.freeze({
    on: true,
    from: двеЦифры(CONFIG.dailyWindow.endHour),     // 21:00
    until: двеЦифры(CONFIG.dailyWindow.startHour)   // 06:00
});

/* Проверка настройки живёт в чистых правилах и там же под тестами —
   здесь только подставляются начальные значения этого приложения. */
export const normalizeQuiet = raw => normalize(raw, QUIET_DEFAULT);

/** Тихий час, как его задал человек. */
export async function loadQuiet() {
    try {
        return normalizeQuiet(await getMeta(QUIET_KEY));
    } catch {
        return { ...QUIET_DEFAULT };
    }
}

/** Сохранить тихий час и сразу переставить расписание под него. */
export async function saveQuiet(value) {
    const quiet = normalizeQuiet(value);
    await setMeta(QUIET_KEY, quiet);
    await planReminders();
    return quiet;
}

/* Разрешение и канал спрашиваем один раз за запуск, а не на каждую
   перестановку расписания: ensureReady обращается к системе, и звать её
   по десять раз на дню незачем. */
let ready = null;

async function readyOnce() {
    if (ready === null) ready = await ensureReady();
    return ready;
}

function lastJumpTime() {
    try {
        return Number(localStorage.getItem('last_quantum_jump_time')) || 0;
    } catch {
        return 0;   // приватный режим браузера — не беда
    }
}

/**
 * Переставить всё расписание заново.
 *
 * Звать можно сколько угодно раз и откуда угодно: прежние напоминания с
 * теми же ключами снимаются сами. Это важнее, чем кажется, — расписание
 * меняется от каждого прожитого момента и каждого прыжка.
 *
 * @returns {Promise<boolean>} поставлено ли хоть одно напоминание
 */
export async function planReminders() {
    if (!isNative()) return false;        // в браузере ставить нечего
    if (!await readyOnce()) return false; // человек не дал разрешения

    const now = new Date();
    const quiet = await loadQuiet();
    const moments = momentPlan(state.quantum?.moments, now, quiet);
    const window = windowPlan(lastJumpTime(), now, {
        cooldownMs: CONFIG.timing.jumpCooldownMs,
        quiet
    });

    /* Сначала снимаем лишнее: прожитые и погашенные моменты, а если окна
       больше нет — и его. Фасад снимает только те ключи, которые ему
       передали на постановку, и про остальные знать не может. */
    const silence = window ? moments.silence : moments.silence.concat(KEY_WINDOW);
    if (silence.length) await cancelKeys(silence);

    const totalSec = Math.floor(CONFIG.timing.opportunityWindowMs / 1000);

    const ring = moments.ring.map(item => ({
        ...item,
        title: t('reminder.moment.title'),
        body: t('reminder.moment.body')
    }));

    if (window) {
        ring.push({
            ...window,
            title: t('reminder.window.title'),
            body: t('reminder.window.body', {
                min: Math.floor(totalSec / 60),
                sec: totalSec % 60
            })
        });
    }

    if (!ring.length) return false;
    return scheduleReminders(ring);
}

/**
 * Связать планировщик с приложением. Звать один раз при запуске.
 *
 * @param {(key: string) => void} onOpen что делать по нажатию на уведомление
 */
export async function initReminders(onOpen) {
    if (!isNative()) return;

    await onReminderAction(onOpen);

    /* Расписание переставляем и когда приложение открыли, и когда закрыли.

       Возвращение понятно: пока приложение было закрыто, человек мог
       прожить момент или дождаться нового дня с новым расписанием.

       А вот УХОД важнее, и это не сразу очевидно. Самый обычный порядок
       такой: человек открыл приложение, совершил прыжок — и ушёл. Прыжок
       сдвинул время следующего окна на 3 часа 33 минуты вперёд. Если
       ставить расписание только при возвращении, новый срок попал бы в
       будильник лишь когда человек в следующий раз откроет приложение
       сам, — то есть ровно тогда, когда напоминание уже не нужно.

       Поэтому переставляем на любую смену видимости, без разбора.

       visibilitychange, а не плагин @capacitor/app: событие штатно
       работает и в браузере, и внутри приложения, и не тянет в проект
       ещё одну зависимость ради одной строки. */
    document.addEventListener('visibilitychange', () => {
        planReminders().catch(err => console.warn('[напоминания]', err));
    });

    await planReminders();
}
