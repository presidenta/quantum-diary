/* ПРАВИЛА НАПОМИНАНИЙ: что должно позвонить и когда.

   Чистые правила без браузера, сети и плагинов — их можно проверить
   тестами, и они проверены (test/reminders.test.js). Всё, что требует
   телефона, живёт этажом выше, в js/reminder-plan.js: там читается
   состояние приложения и зовётся системный будильник.

   Решение здесь принимается в двух видах сразу: что ПОСТАВИТЬ и что
   СНЯТЬ. Второе не менее важно первого. Напоминание, поставленное вчера,
   живёт в системе само по себе и позвонит, даже если момент давно прожит
   или погашен крестиком, — снять его может только приложение, и только
   если знает, что именно снимать. */

import { isOff } from './quantum.js';

export const KEY_WINDOW = 'quantum-window';
export const KEY_MOMENT = 'moment-';

/* Время «ЧЧ:ММ» сегодняшнего дня как момент времени.

   Моменты приходят с сервера строкой без даты: день всегда сегодняшний.
   Непонятную строку возвращаем как null, а не как «полночь» — молчание
   лучше звонка в три часа ночи из-за испорченного поля. */
export function atToday(hhmm, now = new Date()) {
    const parts = String(hhmm).split(':');
    if (parts.length !== 2) return null;

    const h = Number(parts[0]);
    const m = Number(parts[1]);
    if (!Number.isInteger(h) || !Number.isInteger(m)) return null;
    if (h < 0 || h > 23 || m < 0 || m > 59) return null;

    const at = new Date(now);
    at.setHours(h, m, 0, 0);
    return at;
}

/* Минуты от полуночи. Время приходит строкой «ЧЧ:ММ» — так его отдаёт
   поле ввода времени и так его удобно хранить. */
export function minutesOfDay(hhmm) {
    const parts = String(hhmm).split(':');
    if (parts.length !== 2) return null;

    const h = Number(parts[0]);
    const m = Number(parts[1]);
    if (!Number.isInteger(h) || !Number.isInteger(m)) return null;
    if (h < 0 || h > 23 || m < 0 || m > 59) return null;

    return h * 60 + m;
}

/* Тихий час: промежуток, когда телефон молчит.

   Границы задаёт человек в профиле и приходят они сюда снаружи — правило
   не знает ни конкретных цифр, ни того, где они хранятся.

   Промежуток обычно переходит через полночь (с 22:00 до 7:00), и тогда
   проверка идёт на ИЛИ: 23:30 больше начала, 3:00 меньше конца — тихо и
   там, и там. Но человек вправе задать и дневной промежуток, скажем с
   13:00 до 15:00, — тогда работает обычное «между», на И. Поэтому две
   ветки, а не одна.

   Равные границы — это «тихо никогда», а не «тихо всегда». Так понятнее
   человеку: случайно выставив одинаковое время, он останется с рабочими
   напоминаниями, а не с мёртвой тишиной, причину которой потом не
   найдёт. */
export function isQuietTime(date, from, until) {
    const start = minutesOfDay(from);
    const end = minutesOfDay(until);
    if (start === null || end === null || start === end) return false;

    const now = date.getHours() * 60 + date.getMinutes();
    return start > end
        ? (now >= start || now < end)   // через полночь
        : (now >= start && now < end);  // внутри одних суток
}

/* Приводим что угодно к годной настройке тихого часа.

   Читаем мы её из хранилища телефона, а туда могла попасть и чепуха:
   запись от прежней версии, недописанное сохранение, правка руками.
   Поэтому каждое поле проверяется по отдельности и негодное заменяется
   начальным — одно испорченное значение не должно ронять напоминания
   целиком.

   Начальные значения приходят снаружи: правило не знает, какой час в
   этом приложении считается тихим по умолчанию. */
export function normalizeQuiet(raw, fallback) {
    const src = raw && typeof raw === 'object' ? raw : {};
    const годное = v => (minutesOfDay(v) === null ? null : v);

    return {
        on: src.on !== false,
        from: годное(src.from) || fallback.from,
        until: годное(src.until) || fallback.until
    };
}

/* Попадает ли срок в тихий час.

   Настройка приходит одним объектом {on, from, until} прямо из профиля.
   Выключена или не задана — тихого часа нет, и звонит всё. */
function underQuiet(at, quiet) {
    if (!quiet?.on) return false;
    return isQuietTime(at, quiet.from, quiet.until);
}

/* Моменты дня: что поставить, а что снять.

   Звонить стоит только о том моменте, который ещё впереди, ещё не прожит
   и не погашен крестиком. Обо всех остальных — снимать, и именно поэтому
   список снятия перечисляет их поимённо, а не молчит о них.

   ТИХИЙ ЧАС ДЕЙСТВУЕТ И ЗДЕСЬ. Сначала он задумывался только для окна
   возможностей — его-то время считается само и может упасть на три ночи,
   а моменты назначает администратор вручную. Но человек просил другого:
   чтобы в тихий час приложение не беспокоило вовсе. Значит, молчат оба
   источника, иначе настройка обманывала бы — называлась бы «не
   беспокоить», а половина напоминаний всё равно звонила бы.

   Попавший в тишину момент именно СНИМАЕТСЯ, а не откладывается на утро:
   момент живёт сорок минут и к утру давно просрочен. Звонить о нём позже
   значило бы звать человека к тому, чего уже нет. */
export function momentPlan(moments, now = new Date(), quiet = null) {
    const ring = [];
    const silence = [];

    for (const moment of Array.isArray(moments) ? moments : []) {
        const key = KEY_MOMENT + moment.id;
        const at = atToday(moment.at, now);

        if (isOff(moment) || moment.doneAt || !at || at.getTime() <= now.getTime()
            || underQuiet(at, quiet)) {
            silence.push(key);
            continue;
        }
        ring.push({ key, at });
    }

    return { ring, silence };
}

/* Окно возможностей: открывается через заданный срок после прыжка.

   Возвращаем null, когда ставить нечего, и у каждого «нечего» своя
   причина: прыжка ещё не было, окно уже открылось (звонить поздно) или
   срок пришёлся на тихий час. */
export function windowPlan(lastJump, now = new Date(), options = {}) {
    const { cooldownMs = 0, quiet = null } = options;

    const last = Number(lastJump);
    if (!Number.isFinite(last) || last <= 0) return null;

    const at = new Date(last + cooldownMs);
    if (at.getTime() <= now.getTime()) return null;
    if (underQuiet(at, quiet)) return null;

    return { key: KEY_WINDOW, at };
}
