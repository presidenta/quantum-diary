/* Механика раздела: экраны, таймеры, двери, дневник, хроники.

   Часть раздела «Квант» — вторая вкладка «Пространство вариантов».
   Модуль изолирован: кроме этой папки и двух строк в app.js он ничего
   в Ежедневнике не трогает. */

import { CONFIG } from './config.js';
import { statKey, chronicleRows } from './chronicle-stats.js';
import { NotificationManager } from './notifications.js';
import { QuantumCorridorScene } from './scene.js';
import {
    saveDoorAudio, getDoorAudio, getDoorAudioMeta, deleteDoorAudio,
    canRecord, startRecording, formatDuration
} from './audio.js';
import {
    getDoorPhotos, countDoorPhotos, addDoorPhotos, deleteDoorPhoto, PHOTO_LIMIT
} from './photos.js';
/* Системный будильник телефона. Раздел знает время следующего окна —
   значит, он же и переставляет напоминание, когда это время меняется. */
import { planReminders, loadAlarm, loadQuiet, observerNamedHour, observerNamedSetAt, observerQuiet } from '../../reminder-plan.js';
import { observerClock, countdownText } from '../../core/observer-clock.js';
import { logEvent } from '../../core/web-journal.js';

/* Языки раздела — те же и в том же порядке, что в Ежедневнике.
   Название языка пишется на нём самом, поэтому переводить его не нужно. */
const LANGS = [
    { code: 'ru', flag: '\u{1F1F7}\u{1F1FA}', label: 'Рус', name: 'Русский' },
    { code: 'uk', flag: '\u{1F1FA}\u{1F1E6}', label: 'Укр', name: 'Українська' },
    { code: 'en', flag: '\u{1F1EC}\u{1F1E7}', label: 'Eng', name: 'English' }
];

export class QuantumApp {
    constructor(rootEl) {
        this.rootEl = rootEl || null;   // корень модуля (.qm-root)
        this._destroyed = false;
        this._raf = null;
        this._timeouts = [];

        this.lang = localStorage.getItem('quantum_lang') || 'ru';
        this.realities = JSON.parse(localStorage.getItem('quantum_doors_texts') || '[]');

        // Неизменные id дверей: к ним привязаны записи, поэтому правка текста
        // или перестановка дверей аудио не теряет.
        this.doorIds = JSON.parse(localStorage.getItem('quantum_doors_ids') || '[]');
        this.syncDoorIds(this.realities.length);
        this.clearStoredPlaceholders();

        this.doorMediaFlags = {};        // что лежит в каждой двери
        this.screenBeforeSetup = 'screen-1';  // куда вернуть из настройки
        this.currentDoorId = null;       // дверь, выбранная в коридоре
        this.currentAudioRecord = null;  // её запись, если она есть
        this.audioEl = null;             // проигрыватель
        this.audioUrl = null;            // ссылка на blob, её надо освобождать
        this.recorder = null;            // активный диктофон
        this.recordingDoorId = null;     // дверь, которую сейчас записываем
        this.recTimer = null;            // отсчёт секунд во время записи
        this.smileyLocked = false;       // смайлик зажмурился и остался таким
        this.diaryPicked = new Set();    // отмеченные слова состояний, «ряд:слово»
        this.diaryText = '';             // кусок записи, собранный из этих слов
        this.history = JSON.parse(localStorage.getItem('quantum_akashi_chronicles') || '[]');
        this.notifications = new NotificationManager();
        this.selectedSpeed = 1; // 1: Быстрый переход, 2: Глубокое погружение
        this.windowTriggered = false;

        /* Каждый кусок заводится отдельно и под присмотром.

           Раньше ошибка в любом из них обрывала конструктор целиком. Если
           спотыкался шаг до initUI, обработчики кнопок не навешивались
           вовсе: раздел открывался, рисовался, но ни одна кнопка не
           работала — в том числе «Войти в суперпозицию». Теперь сломанный
           кусок остаётся сломанным, а всё остальное живёт.

           Кнопки заводятся первыми: без них раздел бесполезен. */
        this.safely('кнопки раздела', () => this.initUI());
        this.safely('песочная анимация', () => this.initSandFX());
        this.safely('частицы заголовка', () => this.initInnerQuantums());
        this.safely('переключатель языков', () => this.initLangSwitcher());
        this.safely('смайлик', () => this.initSmiley());
        this.safely('длинные вступления', () => this.initFolds());
        this.safely('подписи', () => this.applyLang());
        this.safely('расписание', () => this.checkScheduleAndTimer());
    }

    /* Заводит кусок раздела, не роняя остальные. */
    safely(what, step) {
        try {
            step();
        } catch (err) {
            console.error('[space] не удалось завести: ' + what, err);
        }
    }

    /* Модуль ищет элементы только внутри себя.

       Рядом на той же странице живёт Ежедневник, и его элементы трогать
       нельзя: у него сотня своих подписей, и чужой словарь подставил бы им
       служебные ключи вместо текста. */
    $(id) {
        return (this.rootEl || document).querySelector('#' + id);
    }

    $$(selector) {
        return (this.rootEl || document).querySelectorAll(selector);
    }

    /* Перевод с двумя запасными ходами.

       Прежняя строка читала словарь напрямую: CONFIG.translations[this.lang][key].
       Стоило языку прийти кодом, которого в словаре нет — а украинский в
       Ежедневнике и в игре встречается и как 'uk', и как 'ua', — и обращение
       к несуществующему словарю обрывало перевод всего экрана целиком.

       Теперь неизвестный код сводится к русскому, неизвестный ключ ищется в
       русском словаре, и только если нет и там — на экран идёт сам ключ.
       Это последняя черта: до неё человек не должен видеть служебных имён. */
    t(key) {
        const dict = CONFIG.translations[this.lang] || CONFIG.translations.ru;
        return dict[key] || CONFIG.translations.ru[key] || key;
    }

    // Экранирование текста пользователя перед вставкой в HTML
    escapeHtml(value) {
        return String(value === null || value === undefined ? '' : value)
            .replace(/[&<>"']/g, function (ch) {
                return {
                    '&': '&amp;',
                    '<': '&lt;',
                    '>': '&gt;',
                    '"': '&quot;',
                    "'": '&#39;'
                }[ch];
            });
    }

    // Отложенный вызов с запоминанием таймера — чтобы снять его при уходе
    later(fn, ms) {
        const id = setTimeout(() => {
            if (!this._destroyed) fn();
        }, ms);
        this._timeouts.push(id);
        return id;
    }

    initInnerQuantums() {
        // Координаты центров кругов SVG "Цветка жизни"
        this.flowerCircles = [
            {x: 100, y: 100},
            {x: 100, y: 65},
            {x: 130.3, y: 82.5},
            {x: 130.3, y: 117.5},
            {x: 100, y: 135},
            {x: 69.7, y: 117.5},
            {x: 69.7, y: 82.5}
        ];

        // Логика двух квантов
        this.q2 = { circle: 0, angle: 0, speed: 0.02, cooldown: 0 };
        this.q3 = { circle: 4, angle: Math.PI, speed: -0.025, cooldown: 0 };

        const animateQ = () => {
            if (this._destroyed) return;

            const screen1 = document.getElementById('screen-1');
            if (!screen1 || screen1.classList.contains('hidden')) {
                this._raf = requestAnimationFrame(animateQ);
                return;
            }

            const r = 35;

            // Обновление кванта 2
            this.q2.angle += this.q2.speed;
            if (this.q2.cooldown > 0) this.q2.cooldown--;
            let p2x = this.flowerCircles[this.q2.circle].x + r * Math.cos(this.q2.angle);
            let p2y = this.flowerCircles[this.q2.circle].y + r * Math.sin(this.q2.angle);

            // Обновление кванта 3
            this.q3.angle += this.q3.speed;
            if (this.q3.cooldown > 0) this.q3.cooldown--;
            let p3x = this.flowerCircles[this.q3.circle].x + r * Math.cos(this.q3.angle);
            let p3y = this.flowerCircles[this.q3.circle].y + r * Math.sin(this.q3.angle);

            // Избежание столкновений
            if (Math.hypot(p2x - p3x, p2y - p3y) < 15) {
                this.q2.speed *= -1;
                this.q3.speed *= -1;
                this.q2.angle += this.q2.speed * 2;
                this.q3.angle += this.q3.speed * 2;
            }

            // Логика перехода между орбитами в точках соприкосновения (q2)
            if (this.q2.cooldown === 0) {
                for (let i = 0; i < 7; i++) {
                    if (i === this.q2.circle) continue;
                    if (Math.abs(Math.hypot(p2x - this.flowerCircles[i].x, p2y - this.flowerCircles[i].y) - r) < 1.0) {
                        if (Math.random() < 0.4) {
                            this.q2.circle = i;
                            this.q2.angle = Math.atan2(p2y - this.flowerCircles[i].y, p2x - this.flowerCircles[i].x);
                            this.q2.cooldown = 40;
                            break;
                        }
                    }
                }
            }

            // Логика перехода между орбитами в точках соприкосновения (q3)
            if (this.q3.cooldown === 0) {
                for (let i = 0; i < 7; i++) {
                    if (i === this.q3.circle) continue;
                    if (Math.abs(Math.hypot(p3x - this.flowerCircles[i].x, p3y - this.flowerCircles[i].y) - r) < 1.0) {
                        if (Math.random() < 0.4) {
                            this.q3.circle = i;
                            this.q3.angle = Math.atan2(p3y - this.flowerCircles[i].y, p3x - this.flowerCircles[i].x);
                            this.q3.cooldown = 40;
                            break;
                        }
                    }
                }
            }

            /* Перевод из координат рисунка в пиксели экрана.

               Прежде здесь стояли числа 0.55 и 10 — масштаб и отступ,
               снятые с цветка в 110 пикселей внутри поля в 130. Цветок
               вырос, числа остались, и кванты поехали мимо рисунка: со
               стороны это выглядело хаосом, хотя сам движок вёл их по
               окружностям верно.

               Теперь масштаб берётся из самого узла. Сторона viewBox у
               цветка 200, отсюда и делитель; отступ — половина разницы
               между полем и рисунком. Поменяется размер — пересчитается
               само. */
            const iq1 = document.getElementById('iq1');
            const iq2 = document.getElementById('iq2');
            const svg = document.querySelector('.qm-root .flower-svg');
            const поле = document.querySelector('.qm-root .flower-orbit-container');
            if (iq1 && iq2 && svg && поле) {
                const сторона = svg.clientWidth || 160;
                const масштаб = сторона / 200;
                const отступ = ((поле.clientWidth || сторона) - сторона) / 2;
                iq1.style.left = (отступ + p2x * масштаб) + 'px';
                iq1.style.top = (отступ + p2y * масштаб) + 'px';
                iq2.style.left = (отступ + p3x * масштаб) + 'px';
                iq2.style.top = (отступ + p3y * масштаб) + 'px';
            }

            this._raf = requestAnimationFrame(animateQ);
        };
        animateQ();
    }

    /* Переключатель языков: одна кнопка с текущим языком, по нажатию —
       список остальных.

       Раздел занимает весь экран и перекрывает кнопку языка Ежедневника,
       поэтому своя здесь обязательна. Выбор уходит наружу событием: язык в
       Ежедневнике и в разделе должен остаться одним, а менять чужое
       состояние напрямую модуль не вправе. */
    initLangSwitcher() {
        const button = this.$('qm-lang-btn');
        const menu = this.$('qm-lang-menu');
        if (!button || !menu) return;

        /* Список собирается по одному элементу, без replaceChildren:
           эта команда появилась в браузерах недавно, а раздел должен
           открываться и на старом движке. */
        menu.innerHTML = '';

        for (const item of LANGS) {
            const row = document.createElement('button');
            row.type = 'button';
            row.className = 'qm-lang-item';
            row.dataset.lang = item.code;

            const name = document.createElement('span');
            name.className = 'qm-lang-name';
            name.textContent = item.flag + ' ' + item.name;
            row.appendChild(name);

            const code = document.createElement('span');
            code.className = 'qm-lang-code';
            code.textContent = item.label;
            row.appendChild(code);

            row.addEventListener('click', () => {
                this.closeLangMenu();
                this.setLang(item.code);
            });

            menu.appendChild(row);
        }

        button.addEventListener('click', () => {
            const open = menu.hidden;
            menu.hidden = !open;
            button.setAttribute('aria-expanded', String(open));
        });

        // Клик мимо списка закрывает его. Слушаем на корне раздела, чтобы
        // не оставлять обработчик на всей странице после ухода отсюда.
        if (this.rootEl) {
            this.rootEl.addEventListener('click', e => {
                if (!e.target.closest('#lang-switcher-container')) this.closeLangMenu();
            });
        }
    }

    closeLangMenu() {
        const button = this.$('qm-lang-btn');
        const menu = this.$('qm-lang-menu');
        if (menu) menu.hidden = true;
        if (button) button.setAttribute('aria-expanded', 'false');
    }

    setLang(code) {
        if (!LANGS.some(item => item.code === code)) return;

        this.lang = code;
        localStorage.setItem('quantum_lang', code);
        this.applyLang();

        // Просим Ежедневник переключиться следом, чтобы язык был один
        document.dispatchEvent(new CustomEvent('qm-lang-change', { detail: code }));
    }

    /* Смайлик жмурится от любого прикосновения.

       На наведение, касание и фокус — пока взаимодействие длится. После
       нажатия остаётся зажмуренным, пока не выберут новую дверь. Одним CSS
       так не выйдет: :hover и :active отпускают состояние сразу. */
    /* Смайлик — лицо всей капсулы.

       Он закрывает глаза, когда палец или курсор оказывается на любой её
       части: и на пластине «Закрой глаза», и на круглом Play. Уходит —
       открывает. Нажатие на любую половину вдобавок утапливает капсулу
       целиком, чтобы она читалась одной вещью, а не тремя.

       Одного :hover мало: на телефоне он остаётся «залипшим» после
       касания, и глаза закрывались навсегда. */
    initSmiley() {
        const capsule = this.$('qm-act');
        const eyes = this.$('btn-s3');
        const play = this.$('btn-s3-play');
        if (!capsule) return;

        const shut = () => capsule.classList.add('qm-eyes-shut');
        const open = () => { if (!this.smileyLocked) capsule.classList.remove('qm-eyes-shut'); };
        const press = () => capsule.classList.add('qm-act-pressed');
        const release = () => capsule.classList.remove('qm-act-pressed');

        ['pointerenter', 'pointerdown', 'touchstart'].forEach(type => {
            capsule.addEventListener(type, shut, { passive: true });
        });
        ['pointerleave', 'pointercancel'].forEach(type => {
            capsule.addEventListener(type, () => { open(); release(); });
        });

        for (const half of [eyes, play]) {
            if (!half) continue;
            ['pointerdown', 'touchstart'].forEach(type => {
                half.addEventListener(type, () => { shut(); press(); }, { passive: true });
            });
            ['pointerup', 'pointercancel', 'touchend', 'blur'].forEach(type => {
                half.addEventListener(type, release);
            });
            half.addEventListener('focus', shut);
            half.addEventListener('blur', open);
        }

        // Глаза окончательно закрываются только у «Закрой глаза»
        if (eyes) {
            eyes.addEventListener('click', () => {
                this.smileyLocked = true;
                shut();
            });
        }
    }

    /* ---- Длинное вступление под катом ---------------------------------

       Абзац зажат тремя строками, остальное открывается галочкой под ним.
       На телефоне такая фраза занимала четверть экрана и отодвигала вниз
       всё, ради чего человек сюда пришёл.

       Галочка висит не всегда. Если текст и так уместился в три строки —
       а на широком экране он умещается, — показывать её незачем: это и
       проверяет measureFolds, сравнивая полную высоту абзаца с видимой.

       Мерить можно только когда экран показан: у спрятанного .hidden
       высота нулевая, и любое сравнение дало бы «не влезает». Поэтому
       замер зовут showScreen, applyLang и поворот экрана, а не
       конструктор. */
    initFolds() {
        this.$$('.qm-fold').forEach(fold => {
            const btn = fold.querySelector('.qm-fold-btn');
            if (!btn) return;
            btn.addEventListener('click', () => {
                const open = fold.classList.toggle('qm-open');
                btn.setAttribute('aria-expanded', String(open));
            });
        });
    }

    measureFolds() {
        this.$$('.qm-fold').forEach(fold => {
            const text = fold.querySelector('.qm-fold-text');
            const btn = fold.querySelector('.qm-fold-btn');
            if (!text || !btn || !text.offsetHeight) return;

            /* Открытому абзацу галочка нужна всегда: иначе свернуть его
               обратно будет нечем — в раскрытом виде он по определению
               «помещается». */
            const clipped = text.scrollHeight - text.clientHeight > 2;
            btn.hidden = !clipped && !fold.classList.contains('qm-open');
        });
    }

    /* ---- Слова состояний ------------------------------------------------

       Три ряда слов над полем записи: что чувствую, что ощущаю телом и
       где. Нажатое слово загорается золотом и само встаёт в запись;
       нажатое второй раз — гаснет и из записи уходит. Квадратиков и
       галочек нет: выбор виден по самому слову.

       Выбор держится парой номеров «ряд:слово», а не самим словом. Тогда
       смена языка его не теряет: ряды перерисуются по-другому, а
       отмеченным останется то же самое.

       В поле записи собранные слова живут одним куском, и этот кусок
       запомнен дословно в this.diaryText. Новый кусок подменяет старый
       на месте — поэтому всё, что человек дописал руками вокруг, остаётся
       нетронутым, и поле остаётся обычным полем для письма, а не выводом
       машины. Если старого куска в поле уже нет (стёрли вручную), новый
       дописывается в конец. */
    tagGroups() {
        const all = CONFIG.diaryTags || {};
        return all[this.lang] || all.ru || [];
    }

    renderDiaryTags() {
        const box = this.$('s4-tags');
        if (!box) return;

        const rows = this.tagGroups().map((group, gi) => {
            const row = document.createElement('div');
            row.className = 'qm-tag-group';

            const label = document.createElement('span');
            label.className = 'qm-tag-label';
            label.textContent = group.label;
            row.appendChild(label);

            /* Слова идут в той же строке, что и название ряда: отдельная
               полоса под названием съедала строку на каждый ряд и растила
               блок на треть. Перенос делает сам флекс, когда строка
               кончилась. */
            group.words.forEach((word, wi) => {
                const key = gi + ':' + wi;
                const chip = document.createElement('button');
                chip.type = 'button';
                chip.className = 'qm-tag';
                chip.textContent = word;
                chip.setAttribute('aria-pressed', String(this.diaryPicked.has(key)));
                chip.addEventListener('click', () => {
                    if (this.diaryPicked.has(key)) this.diaryPicked.delete(key);
                    else this.diaryPicked.add(key);
                    chip.setAttribute('aria-pressed', String(this.diaryPicked.has(key)));
                    this.syncDiaryTags();
                });
                row.appendChild(chip);
            });

            return row;
        });

        box.replaceChildren(...rows);
    }

    /* Фраза собирается по рядам и в их порядке:
       «Мои эмоции: радость, эйфория. Ощущаю физически: мурашки.
        В теле сейчас я чувствую: в животе.»
       Пустой ряд пропускается целиком, вместе со своим названием. */
    composeDiaryText() {
        return this.tagGroups().map((group, gi) => {
            const picked = group.words.filter((word, wi) => this.diaryPicked.has(gi + ':' + wi));
            return picked.length ? group.label + ': ' + picked.join(', ') + '.' : '';
        }).filter(Boolean).join(' ');
    }

    syncDiaryTags() {
        const area = this.$('input-s4-diary');
        if (!area) return;

        const next = this.composeDiaryText();
        const prev = this.diaryText;
        let value = area.value;

        if (prev && value.includes(prev)) {
            /* Замена функцией, а не строкой: в слове может оказаться
               доллар, а в строке замены он значил бы подстановку. */
            value = value.replace(prev, () => next);
        } else if (next) {
            value = value.trim() ? value.replace(/\s+$/, '') + '\n' + next : next;
        }

        area.value = value.replace(/\n{3,}/g, '\n\n').replace(/^\s+/, '');
        this.diaryText = next;
    }

    applyLang() {
        // Текущий язык на кнопке и отметка в списке
        const current = LANGS.find(item => item.code === this.lang) || LANGS[0];
        const label = this.$('qm-lang-label');
        if (label) label.textContent = current.flag + ' ' + current.label;

        this.$$('.qm-lang-item').forEach(item => {
            const active = item.dataset.lang === this.lang;
            item.classList.toggle('active', active);
            item.setAttribute('aria-pressed', String(active));
        });

        // Статичные тексты в разметке раздела — и только в ней
        this.$$('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                el.placeholder = this.t(key);
            } else {
                el.innerText = this.t(key);
            }
        });

        /* Слова состояний. Ряды перерисовываются на новом языке, а
           собранный из них кусок в поле записи подменяется с прежнего
           языка на новый — дословно, на месте, не трогая остального. */
        this.renderDiaryTags();
        this.syncDiaryTags();
        this.measureFolds();

        // Динамические элементы.
        // Набранный, но ещё не сохранённый текст дверей переживает смену языка.
        const typedDoors = Array.from(document.querySelectorAll('.door-text-input')).map(inp => inp.value);
        this.renderSetupInputs(typedDoors.length || parseInt(document.getElementById('doors-count-select').value));
        if (typedDoors.length) {
            document.querySelectorAll('.door-text-input').forEach((inp, i) => {
                if (typeof typedDoors[i] === 'string') inp.value = typedDoors[i];
            });
        }

        const closeBtn = document.getElementById('btn-space-close');
        if (closeBtn) {
            closeBtn.setAttribute('aria-label', this.t('btnCloseSection'));
            closeBtn.title = this.t('btnCloseSection');
        }

        const gear = this.$('btn-gear');
        if (gear) {
            gear.setAttribute('aria-label', this.t('btnSettings'));
            gear.title = this.t('btnSettings');
        }

        /* Шестерёнка в хрониках: слова живут в атрибуте, а не в кнопке.
           Подсказку рисует CSS по data-tip, поэтому ставить её через
           data-i18n нельзя — тот пишет в содержимое и выбросил бы значок.
           title оставлен для тех, кто ведёт мышью и ждёт обычной
           системной подсказки. */
        const doorsGear = this.$('btn-edit-from-s5');
        if (doorsGear) {
            const label = this.t('btnEditFromS5');
            doorsGear.setAttribute('data-tip', label);
            doorsGear.setAttribute('aria-label', label);
            doorsGear.title = label;
        }

        this.renderChronicles();
        this.updateSnoozeButtonUI();
        this.updateSpeedUI();
    }

    initUI() {
        // Кнопка Старт с золотым салютом
        document.getElementById('btn-start-app').addEventListener('click', () => {
            this.triggerSandShower(() => this.checkFirstTimeOrCorridor());
        });

        // Настройки реальностей
        document.getElementById('btn-open-settings').addEventListener('click', (e) => {
            e.preventDefault();
            this.openSettingsScreen();
        });
        document.getElementById('btn-edit-from-s5').addEventListener('click', () => this.openSettingsScreen());

        // Шестерёнка на главном экране: тот же экран настройки
        const gear = this.$('btn-gear');
        if (gear) gear.addEventListener('click', () => this.openSettingsScreen());
        document.getElementById('doors-count-select').addEventListener('change', (e) => this.renderSetupInputs(parseInt(e.target.value)));

        // Панели аудио пересоздаются при каждой перерисовке дверей,
        // поэтому слушаем контейнер, а не каждую кнопку по отдельности.
        const doorsBox = document.getElementById('doors-inputs-container');
        doorsBox.addEventListener('click', (e) => this.onDoorAudioClick(e));
        doorsBox.addEventListener('change', (e) => this.onDoorAudioFile(e));

        // Значок готовности зажигается сразу, как в поле появился текст
        doorsBox.addEventListener('input', (e) => {
            if (!e.target.classList.contains('door-text-input')) return;
            const row = e.target.closest('.qm-door-row');
            if (row) this.updateDoorStatus(row);
        });
        document.getElementById('btn-save-setup').addEventListener('click', () => this.saveSettingsAndStart());
        document.getElementById('btn-cancel-setup').addEventListener('click', () => this.closeSettingsScreen());

        // Переключения табов скорости на экране Настройка реальности
        document.querySelectorAll('.speed-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                const btn = e.target.closest('.speed-tab');
                if (btn) {
                    this.selectedSpeed = parseInt(btn.getAttribute('data-speed'));
                    this.updateSpeedUI();
                }
            });
        });

        /* Составная кнопка.

           Левая половина — «Закрой глаза»: отсчёт и переход на дневник.
           Правая — слушать запись этой двери, и только это. Раньше она
           тоже запускала переход, просто со звуком: нажать и послушать,
           ничего больше не делая, было нельзя. */
        document.getElementById('btn-s3').addEventListener('click', () => this.handleEyeCloseTransition(false));
        const playZone = document.getElementById('btn-s3-play');
        if (playZone) playZone.addEventListener('click', () => this.toggleDoorAudio());
        document.getElementById('btn-s4-save').addEventListener('click', () => this.activateAkasha());

        // Крестик не закрывает раздел сам: он лишь сообщает об этом наружу,
        // а что делать дальше — решает тот, кто модуль подключил.
        const closeBtn = document.getElementById('btn-space-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                if (this.rootEl) {
                    this.rootEl.dispatchEvent(new CustomEvent('qm-close', { bubbles: true }));
                }
            });
        }

        // Кнопки модального окна "Окно возможностей открыто"
        document.getElementById('btn-modal-start').addEventListener('click', () => {
            this.hideOpportunityModal();
            this.triggerSandShower(() => this.checkFirstTimeOrCorridor());
        });

        // Отложить на десять минут прямо из окна и закрыть его
        const snooze = document.getElementById('btn-snooze');
        if (snooze) {
            snooze.addEventListener('click', () => {
                this.handleSnooze();
                this.hideOpportunityModal();
            });
        }
    }

    updateSpeedUI() {
        document.querySelectorAll('.speed-tab').forEach(tab => {
            const spd = parseInt(tab.getAttribute('data-speed'));
            tab.classList.toggle('active', spd === this.selectedSpeed);
        });

        const instructionBox = document.getElementById('speed-instruction-text');
        if (instructionBox) {
            const key = this.selectedSpeed === 1 ? 'speedOption1Text' : 'speedOption2Text';
            instructionBox.innerText = this.t(key);
        }
    }

    /**
     * Закрытие глаз и отсчёт до трёх.
     * @param {boolean} withAudio запускать ли аудио двери по окончании отсчёта
     */
    handleEyeCloseTransition(withAudio) {
        const countdownOverlay = document.getElementById('countdown-overlay');
        const countdownNum = document.getElementById('countdown-num');
        const blackout = document.getElementById('blackout-screen');

        if (!countdownOverlay || !countdownNum || !blackout) {
            if (withAudio) this.playCurrentDoorAudio();
            this.showScreen('screen-4');
            return;
        }

        let count = 1;
        countdownNum.innerText = count.toString();
        countdownOverlay.classList.remove('hidden');

        this.countTimer = setInterval(() => {
            count++;
            if (count <= 3) {
                countdownNum.innerText = count.toString();
                countdownNum.style.animation = 'none';
                void countdownNum.offsetWidth;
                countdownNum.style.animation = 'qmCountPulse 0.8s ease-out';
            } else {
                clearInterval(this.countTimer);

                // Отсчёт кончился — аудио стартует здесь, параллельно
                // с уходом экрана в затемнение.
                if (withAudio) this.playCurrentDoorAudio();

                blackout.classList.remove('hidden');
                blackout.classList.add('active');

                this.later(() => {
                    countdownOverlay.classList.add('hidden');
                    blackout.classList.remove('active');
                    blackout.classList.add('hidden');
                    this.showScreen('screen-4');
                }, 1200);
            }
        }, 1000);
    }

    initSandFX() {
        this.sandCanvas = document.getElementById('sand-canvas');
        this.sandCtx = this.sandCanvas.getContext('2d');
        this.resizeSandCanvas();
        /* Поворот телефона меняет ширину, а с ней и число строк в
           свёрнутом вступлении: галочка то нужна, то нет. Замер
           подвешен к тому же слушателю, чтобы не плодить второй. */
        this._onResize = () => { this.resizeSandCanvas(); this.measureFolds(); };
        window.addEventListener('resize', this._onResize);
    }

    resizeSandCanvas() {
        this.sandCanvas.width = window.innerWidth;
        this.sandCanvas.height = window.innerHeight;
    }

    triggerSandShower(callback) {
        const particles = [];
        const count = 150;
        for (let i = 0; i < count; i++) {
            particles.push({
                x: window.innerWidth / 2,
                y: window.innerHeight / 2,
                vx: (Math.random() - 0.5) * 18,
                vy: (Math.random() - 0.8) * 18,
                size: Math.random() * 4 + 2,
                alpha: 1
            });
        }

        let frames = 0;
        const animate = () => {
            if (this._destroyed) return;

            this.sandCtx.clearRect(0, 0, this.sandCanvas.width, this.sandCanvas.height);
            particles.forEach(p => {
                p.x += p.vx;
                p.y += p.vy;
                p.vy += 0.3;
                p.alpha -= 0.015;

                this.sandCtx.fillStyle = `rgba(216, 166, 63, ${Math.max(0, p.alpha)})`;
                this.sandCtx.beginPath();
                this.sandCtx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                this.sandCtx.fill();
            });

            frames++;
            if (frames < 50) {
                requestAnimationFrame(animate);
            } else {
                this.sandCtx.clearRect(0, 0, this.sandCanvas.width, this.sandCanvas.height);
                if (callback) callback();
            }
        };
        animate();
    }

    /* Двери уже настроены — сразу в коридор. Настройка открывается сама
       только при самом первом входе, когда дверей ещё нет. Поправить их в
       любой другой момент можно шестерёнкой на главном экране. */
    checkFirstTimeOrCorridor() {
        if (this.realities.length >= CONFIG.doors.min) {
            this.startCorridorScreen();
        } else {
            this.openSettingsScreen();
        }
    }

    openSettingsScreen() {
        const count = Math.max(CONFIG.doors.min, Math.min(CONFIG.doors.max, this.realities.length || 7));
        document.getElementById('doors-count-select').value = count.toString();
        this.renderSetupInputs(count);
        this.showScreen('screen-setup');
    }

    /* Выход из настройки без сохранения — туда, откуда её открыли.

       Если звали из коридора, коридор и возвращаем: он всё это время жив,
       сцена не пересобирается, пройденное не теряется. */
    closeSettingsScreen() {
        const back = this.screenBeforeSetup;

        if (back === null && this.scene3D) {
            this.showScreen(null);
            return;
        }
        this.showScreen(back || 'screen-1');
    }

    renderSetupInputs(count) {
        const container = document.getElementById('doors-inputs-container');
        container.innerHTML = '';
        this.syncDoorIds(count);

        for (let i = 0; i < count; i++) {
            const val = this.realities[i] || '';
            const placeholderText = this.t('doorPlaceholder').replace('{i}', i + 1);

            const row = document.createElement('div');
            row.className = 'qm-door-row';
            row.dataset.doorId = this.doorIds[i];
            row.dataset.hasAudio = '0';
            row.dataset.photoCount = '0';

            const head = document.createElement('div');
            head.className = 'qm-door-head';

            // Поле создаётся элементом, а не строкой HTML: кавычки и угловые
            // скобки в тексте намерения больше не ломают разметку.
            const input = document.createElement('input');
            input.type = 'text';
            input.className = 'door-text-input';
            input.placeholder = placeholderText;
            input.value = val;
            head.appendChild(input);

            // Значок готовности. Загорается, как только в двери появилось
            // хоть что-то: текст, запись или фотография.
            const badge = document.createElement('span');
            badge.className = 'qm-door-badge';
            badge.textContent = this.t('doorReady');
            badge.hidden = true;
            head.appendChild(badge);

            row.appendChild(head);
            row.appendChild(this.buildDoorMedia());
            container.appendChild(row);
        }

        this.refreshAudioControls();
    }

    /* ---------- Аудио дверей ---------- */

    makeDoorId() {
        return 'd' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    }

    // Список id всегда не короче списка дверей
    syncDoorIds(count) {
        while (this.doorIds.length < count) this.doorIds.push(this.makeDoorId());
    }

    /* Панель под полем двери: запись с микрофона, звуковой файл,
       фотографии, состояние записи и лента снимков.

       Вместо прежней надписи «Добавить аудио» — плашки со значками. Во
       время записи левая плашка превращается в таймер. */
    buildDoorMedia() {
        const box = document.createElement('div');
        box.className = 'qm-media';

        const actions = document.createElement('div');
        actions.className = 'qm-media-actions';

        const record = document.createElement('button');
        record.type = 'button';
        record.className = 'qm-chip qm-chip-rec';
        record.dataset.act = 'record';

        const dot = document.createElement('span');
        dot.className = 'qm-ico qm-ico-mic';
        dot.setAttribute('aria-hidden', 'true');
        record.appendChild(dot);

        const recText = document.createElement('span');
        recText.className = 'qm-chip-text';
        recText.textContent = this.t('audioRecord');
        record.appendChild(recText);

        if (!canRecord()) {
            record.disabled = true;
            record.title = this.t('audioNoRecorder');
        }
        actions.appendChild(record);

        actions.appendChild(this.buildPickChip('file', 'audio/*', false, 'qm-ico-file', this.t('audioPickFile')));

        const photoChip = this.buildPickChip('photo', 'image/*', true, 'qm-ico-photo', this.t('photoAdd'));
        const counter = document.createElement('span');
        counter.className = 'qm-photo-count';
        counter.textContent = '0/' + PHOTO_LIMIT;
        photoChip.appendChild(counter);
        actions.appendChild(photoChip);

        box.appendChild(actions);

        const state = document.createElement('div');
        state.className = 'qm-media-state';

        const info = document.createElement('span');
        info.className = 'qm-audio-info';
        state.appendChild(info);

        state.appendChild(this.buildIconButton('preview', 'qm-audio-preview', this.t('audioPlay')));
        state.appendChild(this.buildIconButton('remove', 'qm-audio-remove', this.t('audioRemove')));
        box.appendChild(state);

        const strip = document.createElement('div');
        strip.className = 'qm-photo-strip';
        box.appendChild(strip);

        return box;
    }

    // Плашка, за которой спрятан выбор файла: по нажатию открывается
    // системный проводник, отдельной кнопки для этого не нужно.
    buildPickChip(act, accept, multiple, iconClass, label) {
        const chip = document.createElement('label');
        chip.className = 'qm-chip';

        const icon = document.createElement('span');
        icon.className = 'qm-ico ' + iconClass;
        icon.setAttribute('aria-hidden', 'true');
        chip.appendChild(icon);

        const text = document.createElement('span');
        text.className = 'qm-chip-text';
        text.textContent = label;
        chip.appendChild(text);

        const input = document.createElement('input');
        input.type = 'file';
        input.accept = accept;
        input.multiple = multiple;
        input.hidden = true;
        input.dataset.act = act;
        chip.appendChild(input);

        return chip;
    }

    buildIconButton(act, extraClass, title) {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'qm-icon-btn ' + extraClass;
        button.dataset.act = act;
        button.title = title;
        button.setAttribute('aria-label', title);
        button.hidden = true;
        return button;
    }

    /* Дверь заполнена, если есть хоть что-то: текст, запись ИЛИ фотография.
       Одного аудио достаточно — так в задании. */
    updateDoorStatus(row) {
        const input = row.querySelector('.door-text-input');
        const badge = row.querySelector('.qm-door-badge');

        const hasText = Boolean(input && input.value.trim());
        const hasAudio = row.dataset.hasAudio === '1';
        const hasPhoto = Number(row.dataset.photoCount || 0) > 0;
        const ready = hasText || hasAudio || hasPhoto;

        row.classList.toggle('qm-door-ready', ready);
        if (badge) badge.hidden = !ready;
    }

    /* Лента снимков двери с кнопкой «убрать» на каждом. */
    async refreshPhotoStrip(row) {
        const strip = row.querySelector('.qm-photo-strip');
        const counter = row.querySelector('.qm-photo-count');
        if (!strip) return;

        const photos = await getDoorPhotos(row.dataset.doorId);
        if (this._destroyed || !row.isConnected) return;

        this.releasePhotoUrls(strip);
        strip.innerHTML = '';

        for (const photo of photos) {
            const cell = document.createElement('div');
            cell.className = 'qm-photo-cell';

            const img = document.createElement('img');
            img.src = URL.createObjectURL(photo.blob);
            img.alt = photo.fileName;
            cell.appendChild(img);

            const drop = document.createElement('button');
            drop.type = 'button';
            drop.className = 'qm-photo-drop';
            drop.dataset.act = 'photo-remove';
            drop.dataset.photoId = photo.id;
            drop.title = this.t('photoRemove');
            drop.setAttribute('aria-label', this.t('photoRemove'));
            cell.appendChild(drop);

            strip.appendChild(cell);
        }

        if (counter) counter.textContent = photos.length + '/' + PHOTO_LIMIT;
        row.dataset.photoCount = String(photos.length);
        this.updateDoorStatus(row);
    }

    // Ссылки на картинки отпускаем при замене ленты: иначе снимки копились
    // бы в памяти при каждой перерисовке дверей.
    releasePhotoUrls(strip) {
        strip.querySelectorAll('img').forEach(img => {
            if (img.src.startsWith('blob:')) URL.revokeObjectURL(img.src);
        });
    }

    /* Таймер записи.

       Показывает, сколько уже пишется, и ведёт круговой указатель — полный
       оборот за минуту. Длительность записи не ограничена, поэтому это
       именно указатель хода, а не полоса до конца. */
    startRecTimer(row) {
        this.stopRecTimer();

        const record = row.querySelector('[data-act="record"]');
        const text = record ? record.querySelector('.qm-chip-text') : null;
        if (!record || !text) return;

        const startedAt = Date.now();
        const tick = () => {
            const seconds = Math.floor((Date.now() - startedAt) / 1000);
            text.textContent = formatDuration(seconds * 1000) || '0:00';
            record.style.setProperty('--qm-rec-turn', ((seconds % 60) / 60).toFixed(3));
        };

        tick();
        this.recTimer = setInterval(tick, 250);
    }

    stopRecTimer() {
        if (this.recTimer) {
            clearInterval(this.recTimer);
            this.recTimer = null;
        }
    }

    // Читает хранилище и расставляет состояние у всех дверей сразу
    async refreshAudioControls() {
        const rows = Array.from(this.$$('.qm-door-row'));
        for (const row of rows) {
            const meta = await getDoorAudioMeta(row.dataset.doorId);
            if (this._destroyed || !row.isConnected) return;
            this.applyAudioState(row, meta);

            await this.refreshPhotoStrip(row);
            if (this._destroyed || !row.isConnected) return;
        }
    }

    applyAudioState(row, meta) {
        const info = row.querySelector('.qm-audio-info');
        const preview = row.querySelector('.qm-audio-preview');
        const remove = row.querySelector('.qm-audio-remove');
        const record = row.querySelector('[data-act="record"]');
        const recText = record ? record.querySelector('.qm-chip-text') : null;
        const isRecording = this.recordingDoorId === row.dataset.doorId;

        row.dataset.hasAudio = meta ? '1' : '0';

        if (record && !record.disabled) {
            record.classList.toggle('qm-chip-rec-on', isRecording);
            // Во время записи подпись ведёт таймер, трогать её здесь нельзя
            if (recText && !isRecording) recText.textContent = this.t('audioRecord');
        }

        if (isRecording) {
            info.textContent = this.t('recElapsed');
            preview.hidden = true;
            remove.hidden = true;
            this.updateDoorStatus(row);
            return;
        }

        if (meta) {
            const length = formatDuration(meta.durationMs);
            info.textContent = meta.fileName + (length ? ' · ' + length : '');
            preview.hidden = false;
            remove.hidden = false;
        } else {
            // Пусто: о том, что можно добавить, говорят сами плашки
            info.textContent = '';
            preview.hidden = true;
            remove.hidden = true;
        }

        this.updateDoorStatus(row);
    }

    onDoorAudioClick(event) {
        const button = event.target.closest('[data-act]');
        if (!button || button.tagName === 'INPUT') return;

        const row = button.closest('.qm-door-row');
        if (!row) return;

        const act = button.dataset.act;
        if (act === 'record') this.toggleRecording(row);
        else if (act === 'preview') this.previewDoorAudio(row);
        else if (act === 'remove') this.removeDoorAudio(row);
        else if (act === 'photo-remove') this.removeDoorPhoto(row, button.dataset.photoId);
    }

    async removeDoorPhoto(row, photoId) {
        if (!photoId) return;
        await deleteDoorPhoto(row.dataset.doorId, photoId);
        if (this._destroyed || !row.isConnected) return;
        await this.refreshPhotoStrip(row);
    }

    async onDoorAudioFile(event) {
        const input = event.target;
        if (!input || !input.dataset) return;

        const row = input.closest('.qm-door-row');
        if (!row) return;

        if (input.dataset.act === 'file') {
            const file = input.files && input.files[0];
            input.value = '';
            if (!file) return;

            const meta = await saveDoorAudio(row.dataset.doorId, file, file.name);
            if (this._destroyed || !row.isConnected) return;
            this.applyAudioState(row, meta);
            return;
        }

        if (input.dataset.act === 'photo') {
            const files = Array.from(input.files || []);
            input.value = '';
            if (files.length === 0) return;

            // Лишние сверх трёх плагин отбрасывает сам и говорит сколько
            const { skipped } = await addDoorPhotos(row.dataset.doorId, files);
            if (this._destroyed || !row.isConnected) return;

            await this.refreshPhotoStrip(row);
            if (skipped > 0) alert(this.t('photoLimitReached'));
        }
    }

    async toggleRecording(row) {
        const doorId = row.dataset.doorId;

        // Второе нажатие по той же двери останавливает запись и сохраняет её
        if (this.recorder && this.recordingDoorId === doorId) {
            const recorder = this.recorder;
            this.recorder = null;
            this.recordingDoorId = null;

            this.stopRecTimer();
            const blob = await recorder.stop();
            const stamp = new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
            const meta = await saveDoorAudio(doorId, blob, this.t('audioRecord') + ' ' + stamp);
            if (this._destroyed || !row.isConnected) return;
            this.applyAudioState(row, meta);
            return;
        }

        if (this.recorder) return;   // уже пишем другую дверь

        try {
            this.recorder = await startRecording();
            this.recordingDoorId = doorId;
            this.applyAudioState(row, null);
            this.startRecTimer(row);
        } catch (err) {
            console.error('[space] микрофон недоступен:', err);
            this.stopRecTimer();
            this.recorder = null;
            this.recordingDoorId = null;
            alert(this.t('audioNoMic'));
        }
    }

    async previewDoorAudio(row) {
        const record = await getDoorAudio(row.dataset.doorId);
        if (!record || this._destroyed) return;

        this.stopDoorAudio();
        this.audioUrl = URL.createObjectURL(record.blob);
        this.audioEl = new Audio(this.audioUrl);
        this.audioEl.onended = () => this.stopDoorAudio();
        this.audioEl.play().catch(() => this.stopDoorAudio());
    }

    async removeDoorAudio(row) {
        await deleteDoorAudio(row.dataset.doorId);
        if (this._destroyed || !row.isConnected) return;
        this.applyAudioState(row, null);
    }

    // Зона «Play» включается, только если у выбранной двери есть запись
    async prepareDoorAudio() {
        const play = document.getElementById('btn-s3-play');
        const warn = document.getElementById('txt-s3-audio-warn');
        if (!play || !warn) return;

        warn.hidden = true;
        this.currentAudioRecord = null;
        this.setPlayButtonState('none');
        if (!this.currentDoorId) return;

        const record = await getDoorAudio(this.currentDoorId);
        if (this._destroyed || !play.isConnected) return;

        if (record && record.blob && record.blob.size > 0) {
            this.currentAudioRecord = record;
            this.setPlayButtonState('ready');
        } else if (record) {
            // Запись числится за дверью, но файл пуст или испорчен
            this.showAudioWarning();
        }
    }

    /* Кнопка Play всегда на своём месте.

       Прежде она появлялась только у двери с записью и пропадала у
       остальных: составная кнопка то была составной, то нет, и место
       под пальцем съезжало. Теперь она стоит всегда, а её вид говорит,
       что сейчас можно: 'none' — записи нет, кнопка приглушена и не
       нажимается; 'ready' — треугольник; 'playing' — квадрат, нажатие
       останавливает. */
    setPlayButtonState(state) {
        const play = document.getElementById('btn-s3-play');
        if (!play) return;

        play.hidden = false;
        play.classList.toggle('qm-play-idle', state === 'none');
        play.classList.toggle('qm-play-on', state === 'playing');
        play.disabled = state === 'none';

        const aria = state === 'none' ? 'audioNoneAria'
            : state === 'playing' ? 'audioStopAria'
            : 'audioPlayAria';
        play.setAttribute('aria-label', this.t(aria));
        play.title = this.t(aria);
    }

    // Нажали Play: играет — остановить, молчит — включить
    toggleDoorAudio() {
        if (!this.currentAudioRecord) return;

        if (this.audioEl && !this.audioEl.paused) {
            this.stopDoorAudio();
            return;
        }
        this.playCurrentDoorAudio();
    }

    showAudioWarning() {
        const warn = document.getElementById('txt-s3-audio-warn');
        const play = document.getElementById('btn-s3-play');
        if (warn) {
            warn.textContent = this.t('audioMissing');
            warn.hidden = false;
        }
        if (play) this.setPlayButtonState('none');
    }

    // Аудио выбранной двери. Играет до конца, экран ему не мешает.
    playCurrentDoorAudio() {
        const record = this.currentAudioRecord;
        if (!record) return;

        this.stopDoorAudio();

        try {
            this.audioUrl = URL.createObjectURL(record.blob);
            this.audioEl = new Audio(this.audioUrl);
            this.audioEl.onended = () => this.stopDoorAudio();
            this.audioEl.onerror = () => {
                this.showAudioWarning();
                this.stopDoorAudio();
            };

            // При входящем звонке браузер сам ставит воспроизведение на паузу.
            // Сами его не возобновляем — это делает человек.
            this.audioEl.onpause = () => this.setPlayButtonState('ready');
            const started = this.audioEl.play();
            if (started && started.catch) started.catch(() => this.showAudioWarning());
            this.setPlayButtonState('playing');
        } catch (err) {
            console.error('[space] не удалось включить аудио:', err);
            this.showAudioWarning();
        }
    }

    stopDoorAudio() {
        if (this.audioEl) {
            this.audioEl.onpause = null;
            this.audioEl.pause();
            this.audioEl.onended = null;
            this.audioEl.onerror = null;
            this.audioEl = null;
        }
        if (this.audioUrl) {
            URL.revokeObjectURL(this.audioUrl);
            this.audioUrl = null;
        }
        // Запись кончилась или её остановили — на кнопке снова треугольник
        if (this.currentAudioRecord) this.setPlayButtonState('ready');
    }

    saveSettingsAndStart() {
        // Идём по строкам, а не по полям: так текст двери и её id остаются
        // одной парой, и пустые двери выпадают вместе со своими id.
        const rows = Array.from(document.querySelectorAll('.qm-door-row'));
        const kept = [];

        for (const row of rows) {
            const input = row.querySelector('.door-text-input');
            const text = input ? input.value.trim() : '';
            const hasAudio = row.dataset.hasAudio === '1';
            const hasPhoto = Number(row.dataset.photoCount || 0) > 0;

            // Дверь живёт, если в ней есть хоть что-то. У двери без текста
            // должно остаться имя — иначе в коридоре она была бы безымянной.
            if (text === '' && !hasAudio && !hasPhoto) continue;

            /* Имя двери хранится таким, каким его написал человек, —
               пустое остаётся пустым.

               Раньше пустой двери тут же подставлялась служебная строка
               «Дверь 1», и она записывалась в саму дверь. Дальше эта
               подпись шла всюду: в коридор, на экран выбора, в хроники —
               и выглядела как содержимое двери, хотя была заглушкой.
               Теперь заглушка живёт только на экране, в doorDisplayName. */
            kept.push({ id: row.dataset.doorId, text: text });
        }

        if (kept.length < CONFIG.doors.min) {
            alert(this.t('doorMinAlert').replace('{min}', CONFIG.doors.min));
            return;
        }

        this.realities = kept.map(door => door.text);
        this.doorIds = kept.map(door => door.id);
        localStorage.setItem('quantum_doors_texts', JSON.stringify(this.realities));
        localStorage.setItem('quantum_doors_ids', JSON.stringify(this.doorIds));
        this.startCorridorScreen();
    }

    startCorridorScreen() {
        this.showScreen(null);
        // Чем называется дверь без текста, знают только флаги — снимаем их
        this.refreshDoorMediaFlags();

        if (!this.scene3D) {
            this.scene3D = new QuantumCorridorScene(
                document.getElementById('three-canvas'),
                (idx, txt) => this.onDoorChosen(idx, txt)
            );
        }

        this.scene3D.setupRealities(this.shuffleDoors());
        this.scene3D.startAnimation();

        let timeLeft = CONFIG.timing.quantumWindowSeconds;
        document.getElementById('hud-timer-val').innerText = timeLeft.toFixed(1);

        if (this.countdownInterval) clearInterval(this.countdownInterval);
        this.countdownInterval = setInterval(() => {
            timeLeft -= 0.1;
            document.getElementById('hud-timer-val').innerText = Math.max(0, timeLeft).toFixed(1);

            if (timeLeft <= 0) {
                clearInterval(this.countdownInterval);
                if (this.scene3D) this.scene3D.isRunning = false;
                this.renderChronicles();
                this.showScreen('screen-5');
            }
            if (this.scene3D && this.scene3D.isSelecting) {
                clearInterval(this.countdownInterval);
            }
        }, 100);
    }

    /* СЛЕПОЙ ВЫБОР.

       Перед каждым входом содержимое дверей тасуется, поэтому запомнить,
       за какой дверью что лежит, нельзя. Тасуется только порядок показа:
       сами двери, их записи и фотографии остаются на своих местах. Обратная
       дорожка doorOrder помнит, какой слот куда встал, — по ней находится и
       аудио двери, и её место в сводке.

       Перемешивание Фишера — Йетса: каждый порядок равновероятен. */
    shuffleDoors() {
        const order = this.realities.map((_, slot) => slot);

        for (let i = order.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            const keep = order[i];
            order[i] = order[j];
            order[j] = keep;
        }

        this.doorOrder = order;
        return order.map(slot => this.doorDisplayName(slot));
    }

    /* Как дверь называется на экране.

       Если человек дал двери имя — берём его. Если нет (дверь живёт одной
       записью или фотографией) — показываем «Дверь N». В самой двери при
       этом по-прежнему пусто. */
    doorDisplayName(slot) {
        const own = (this.realities[slot] || '').trim();
        if (own) return this.shortenTitle(own);

        /* Номеров у дверей нет. Двери меняются: сегодня их три, завтра семь,
           порядок в коридоре каждый раз новый, — номер ничего не значит и
           ничего не говорит о том, что внутри.

           Если человек не дал двери имени, она называется тем, что в ней
           лежит: «Фото» или «Запись». Что именно лежит, знает
           doorMediaFlags: это снимается один раз перед входом в коридор и
           перед показом хроник, чтобы здесь не ждать базу. */
        const flags = this.doorMediaFlags[this.doorIds[slot]] || {};
        if (flags.photos) return this.t('doorTitlePhoto');
        if (flags.audio) return this.t('doorTitleAudio');
        return this.t('doorTitleEmpty');
    }

    /* Короткая подпись двери: первая строка намерения, не длиннее строки.

       В намерении человек пишет сколько хочет. На экране перехода и в
       хрониках нужна одна узнаваемая строка, поэтому берём первую и, если
       она длинная, обрываем по границе слова. */
    shortenTitle(text) {
        const first = text.split(/\r?\n/)[0].trim() || text.trim();
        const LIMIT = 42;
        if (first.length <= LIMIT) return first;

        const cut = first.slice(0, LIMIT);
        const space = cut.lastIndexOf(' ');
        return (space > LIMIT * 0.5 ? cut.slice(0, space) : cut).trimEnd() + '…';
    }

    /* Что лежит в каждой двери — снимком, разом по всем.

       Имя двери без текста зависит от её содержимого, а оно в базе
       устройства и читается не сразу. Собираем всё до того, как имя
       понадобится, и держим под рукой. */
    async refreshDoorMediaFlags() {
        const flags = {};

        for (const doorId of this.doorIds) {
            if (!doorId) continue;
            const [audio, photos] = await Promise.all([
                getDoorAudio(doorId).catch(() => null),
                countDoorPhotos(doorId).catch(() => 0)
            ]);
            flags[doorId] = {
                audio: Boolean(audio && audio.blob && audio.blob.size > 0),
                photos: photos || 0
            };
        }

        if (this._destroyed) return;
        this.doorMediaFlags = flags;
    }

    /* Разовая уборка за прежней ошибкой.

       До этой правки пустым дверям записывалось имя «Дверь 1», «Двері 2»,
       «Door 3» — служебная заглушка попадала в сами двери и оставалась там
       навсегда. Здесь такие строки вычищаются: имя снова становится пустым,
       а на экране его место занимает та же заглушка, но уже честная. */
    clearStoredPlaceholders() {
        const looksGenerated = /^\s*(Дверь|Двері|Door)\s*\d+\s*$/i;
        let touched = false;

        this.realities = this.realities.map(text => {
            if (typeof text === 'string' && looksGenerated.test(text)) {
                touched = true;
                return '';
            }
            return text;
        });

        if (touched) {
            localStorage.setItem('quantum_doors_texts', JSON.stringify(this.realities));
        }
    }

    // Какой слот стоит на этом месте в коридоре
    slotOfDoor(index) {
        if (Array.isArray(this.doorOrder) && Number.isInteger(this.doorOrder[index])) {
            return this.doorOrder[index];
        }
        return index;
    }

    onDoorChosen(index, text) {
        // Новая дверь — смайлик снова открывает глаза
        this.smileyLocked = false;
        // Класс живёт на капсуле целиком, а не на одной её половине
        const capsule = this.$('qm-act');
        if (capsule) capsule.classList.remove('qm-eyes-shut', 'qm-act-pressed');

        // index — место в коридоре, а двери перетасованы: берём слот
        const slot = this.slotOfDoor(index);
        this.currentSlot = slot;

        this.currentChosenText = this.doorDisplayName(slot);
        this.currentDoorId = this.doorIds[slot] || null;
        // Дверь выбрана — суперпозиция пройдена, окно закрыто
        this.rememberJump();
        document.getElementById('txt-s3-chosen-reality').innerText = this.currentChosenText;
        this.updateSpeedUI();
        this.showScreen('screen-3');
        this.prepareDoorAudio();
        this.renderChosenDoorMedia();
    }

    /* Снимки выбранной двери прямо на экране перехода.

       Раньше здесь была одна строка с названием двери и больше ничего:
       что человек в эту дверь положил — слышно и видно не было. Теперь её
       снимки показываются тут же, а запись слышна правой половиной
       составной кнопки. */
    async renderChosenDoorMedia() {
        const box = document.getElementById('s3-door-media');
        if (!box) return;

        this.releasePhotoUrls(box);
        box.innerHTML = '';
        box.hidden = true;
        if (!this.currentDoorId) return;

        const photos = await getDoorPhotos(this.currentDoorId);
        if (this._destroyed || !box.isConnected) return;
        if (!photos.length) return;

        /* Снимок раскрывается по нажатию.

           Маленькую плитку 92 на 92 человек положил в дверь не для того,
           чтобы гадать, что на ней. Нажал — снимок разворачивается во всю
           ширину карточки и в своих пропорциях, страница листается дальше.
           Нажал ещё раз — свернулся обратно.

           Раскрыть можно хоть все три сразу: они встают столбиком одна под
           другой. Поэтому это не просмотрщик поверх экрана, а обычный
           поток — сравнивать снимки удобнее, когда они рядом, а не по
           очереди в чёрном окне.

           Плитка — кнопка, а не див: её видит клавиатура и читает
           озвучка, и нажатие приходит само, без своего обработчика
           клавиш. */
        for (const photo of photos) {
            const cell = document.createElement('button');
            cell.type = 'button';
            cell.className = 'qm-s3-photo';
            cell.setAttribute('aria-expanded', 'false');
            cell.title = this.t('photoZoom');
            cell.setAttribute('aria-label', this.t('photoZoom'));

            const img = document.createElement('img');
            img.src = URL.createObjectURL(photo.blob);
            img.alt = photo.fileName || '';
            cell.appendChild(img);

            cell.addEventListener('click', () => {
                const open = cell.classList.toggle('qm-s3-open');
                cell.setAttribute('aria-expanded', String(open));
                const key = open ? 'photoShrink' : 'photoZoom';
                cell.title = this.t(key);
                cell.setAttribute('aria-label', this.t(key));
            });

            box.appendChild(cell);
        }

        box.hidden = false;
    }

    /* Нажали фолиант: удар света, вихрь искр, и только потом запись.

       Сохранение не задерживается ради красоты: оно идёт сразу, а на
       экран хроник переходим, дав искрам долететь. Если человек нажмёт
       второй раз, пока летят искры, ничего не задвоится — кнопка на это
       время не слушает. */
    activateAkasha() {
        const btn = document.getElementById('btn-s4-save');
        const label = document.getElementById('qm-tome-text');
        if (this.akashaBusy) return;
        this.akashaBusy = true;

        if (btn) btn.classList.add('qm-tome-on');
        this.burstAkashaSparks();

        if (label) {
            label.style.opacity = '0';
            this.later(() => {
                if (this._destroyed || !label.isConnected) return;
                label.textContent = this.t('akashaDone');
                /* «Свершилось» пишется белым по потемневшему фолианту.
                   Прорезанное золото на этот миг снимается: оно задано
                   через !important и собственный цвет перебить не даст. */
                label.classList.remove('gold-cut');
                label.style.color = '#FFFFFF';
                label.style.opacity = '1';
            }, 300);
        }

        this.later(() => {
            this.akashaBusy = false;
            if (btn) btn.classList.remove('qm-tome-on');
            if (label) {
                label.style.opacity = '';
                label.style.color = '';
                label.classList.add('gold-cut');   // золото вернулось
                label.textContent = this.t('screen4Btn');
            }
            if (this._destroyed) return;
            this.saveDiaryEntry();
        }, 1100);
    }

    /* Вихрь Акаши: золотые и синие искры летят вверх по спирали.

       Холст живёт только пока летят искры: кадры заказываются от первой
       искры до последней и сами прекращаются. Отдельного вечного цикла
       нет — экран дневника не должен жечь батарею, пока человек пишет. */
    burstAkashaSparks() {
        const canvas = document.getElementById('qm-tome-sparks');
        if (!canvas || !canvas.getContext) return;

        const ctx = canvas.getContext('2d');
        const dpr = Math.min(2, window.devicePixelRatio || 1);
        const w = canvas.offsetWidth || 300;
        const h = canvas.offsetHeight || 220;
        canvas.width = Math.round(w * dpr);
        canvas.height = Math.round(h * dpr);
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

        const sparks = [];
        for (let i = 0; i < 70; i++) {
            sparks.push({
                // Искры поднимаются по всей ширине переплёта, а не из точки
                x: w * (0.18 + Math.random() * 0.64),
                y: h - Math.random() * 6,
                size: Math.random() * 3 + 1,
                up: Math.random() * -3 - 2,
                side: (Math.random() - 0.5) * 4,
                color: Math.random() > 0.7 ? '#4DB8FF' : '#FFD700',
                life: 1,
                decay: Math.random() * 0.02 + 0.015,
                angle: Math.random() * Math.PI * 2,
                spin: (Math.random() - 0.5) * 0.1
            });
        }

        const step = () => {
            if (this._destroyed || !canvas.isConnected) return;
            ctx.clearRect(0, 0, w, h);

            for (let i = sparks.length - 1; i >= 0; i--) {
                const s = sparks[i];
                s.y += s.up;
                s.angle += s.spin;
                s.x += s.side + Math.sin(s.angle) * 2;
                s.life -= s.decay;

                if (s.life <= 0) { sparks.splice(i, 1); continue; }

                ctx.globalAlpha = s.life;
                ctx.fillStyle = s.color;
                ctx.shadowBlur = 10;
                ctx.shadowColor = s.color;
                ctx.beginPath();
                ctx.arc(s.x, s.y, s.size, 0, Math.PI * 2);
                ctx.fill();
            }

            ctx.globalAlpha = 1;
            ctx.shadowBlur = 0;

            if (sparks.length) {
                this._sparkRaf = requestAnimationFrame(step);
            } else {
                ctx.clearRect(0, 0, w, h);
                this._sparkRaf = null;
            }
        };

        if (this._sparkRaf) cancelAnimationFrame(this._sparkRaf);
        this._sparkRaf = requestAnimationFrame(step);
    }

    /* ПРЫЖОК СОВЕРШЁН: С ЭТОГО МИГА ОКНО ЗАКРЫТО, СЛЕДУЮЩЕЕ — ЧЕРЕЗ 3 Ч 33 МИН.

       Владелец 18.10.2026: «прошёл суперпозицию — и сразу опять звонок, что окно открыто». Прыжок
       записывался только сохранением записи в дневник в самом конце; выбрал дверь и закрыл — для
       часов Наблюдателя прыжка не было, окно оставалось открытым и звало снова. Теперь прыжок —
       уже выбор двери (onDoorChosen), а запись в дневник лишь передвигает его на свой миг.

       Расписание переставляется сразу, не дожидаясь ухода из приложения: иначе телефон позвонил
       бы по старому сроку. */
    rememberJump() {
        logEvent('⤴');
        localStorage.setItem('last_quantum_jump_time', Date.now().toString());
        this.notifications.resetSnooze();
        this.windowTriggered = false;
        this.hideOpportunityModal();
        planReminders().catch(err => console.warn('[напоминания]', err));
    }

    saveDiaryEntry() {
        const trace = document.getElementById('input-s4-diary').value.trim();

        /* ts и doorId нужны сводке.

           ts — чтобы отделить сутки от всего времени; раньше в записи была
           только строка с датой, по ней не посчитаешь.

           doorId — чтобы считать по самой двери, а не по её названию:
           переименовал дверь, и статистика продолжилась под новым именем,
           а не завелась заново. */
        this.history.unshift({
            ts: Date.now(),
            slot: Number.isInteger(this.currentSlot) ? this.currentSlot : null,
            doorId: this.currentDoorId || null,
            dateStr: new Date().toLocaleString('ru-RU', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }),
            reality: this.currentChosenText,
            trace: trace || this.t('emptyTrace')
        });

        localStorage.setItem('quantum_akashi_chronicles', JSON.stringify(this.history));
        this.rememberJump();

        document.getElementById('input-s4-diary').value = '';
        // Запись ушла в хроники — слова гаснут вместе с ней
        this.diaryPicked.clear();
        this.diaryText = '';
        this.renderDiaryTags();
        this.renderChronicles();
        this.showScreen('screen-5');
    }

    /* Хроники: сутки подробно, всё остальное — сводкой.

       Длинный список всех переходов разрастался в простыню, по которой
       ничего не видно. Теперь сверху — что было за последние сутки, ниже —
       сколько раз открывалась каждая дверь и какую долю это составляет. */
    renderChronicles() {
        const list = document.getElementById('chronicles-list');
        if (!list) return;

        /* Имена дверей без текста зависят от содержимого. Снимок флагов
           уходит в базу и возвращается позже — тогда список перерисуется
           ещё раз, уже с «Фото» и «Запись» вместо пустых подписей. */
        if (!this.statsFlagsPending) {
            this.statsFlagsPending = true;
            this.refreshDoorMediaFlags().then(() => {
                this.statsFlagsPending = false;
                if (this._destroyed || !list.isConnected) return;
                this.paintChronicles(list);
            });
        }

        if (this.history.length === 0) {
            list.innerHTML = `<p class="qm-empty">${this.escapeHtml(this.t('noRecords'))}</p>`;
            return;
        }

        this.paintChronicles(list);
    }

    paintChronicles(list) {
        list.innerHTML = this.renderRecentChronicles() + this.renderChronicleStats();
        this.applyStatShares(list);
        // Табы периода и «Сброс» — одним обработчиком на список (свойство, а не addEventListener:
        // список перерисовывается целиком, и обработчики не копятся)
        list.onclick = (событие) => this.onStatsClick(событие, list);
    }

    /* ПЕРИОД И ТОЧКА ОТСЧЁТА СВОДКИ (выкладка 148, ТЗ владельца 18.10.2026).

       Табы «За неделю» (7 дней), «За месяц» (30 дней), «За всё время» — сводка пересчитывается
       сразу при смене таба, отдельной кнопки «Обновить» нет. Кнопка «Сброс» одна на все табы:
       после подтверждения запоминает миг сброса (analytics_reset_timestamp), и все три периода
       считают только с него. Записи Хроник при этом не трогаются — меняется только выборка
       для шкал. Выбранный таб помнится на этом устройстве. */
    statsPeriod() {
        const сохранённый = localStorage.getItem('quantum_stats_period');
        return ['week', 'month', 'all'].includes(сохранённый) ? сохранённый : 'all';
    }

    statsBaseline() {
        const миг = Number(localStorage.getItem('analytics_reset_timestamp'));
        return Number.isFinite(миг) && миг > 0 ? миг : 0;
    }

    /* С какого мига считать сводку: начало периода или сброс — что позже; 0 — со всех записей */
    statsSince(now = Date.now()) {
        const сутки = 24 * 60 * 60 * 1000;
        const период = { week: 7 * сутки, month: 30 * сутки }[this.statsPeriod()];
        return Math.max(this.statsBaseline(), период ? now - период : 0);
    }

    /* ПРОШЛЫЙ ПЕРИОД ДЛЯ СРАВНЕНИЯ (выкладка 187): неделя — 7 дней перед последними семью, месяц — 30 перед
       последними тридцатью. «За всё время» сравнивать не с чем — null. Прошлое окно начинается раньше
       «Сброса» — тоже null: старый отсчёт с новым не смешиваем. */
    statsBefore(now = Date.now()) {
        const сутки = 24 * 60 * 60 * 1000;
        const период = { week: 7 * сутки, month: 30 * сутки }[this.statsPeriod()];
        if (!период) return null;
        const окно = { since: now - 2 * период, until: now - период };
        return this.statsBaseline() > окно.since ? null : окно;
    }

    onStatsClick(событие, list) {
        const таб = событие.target.closest('[data-stats-period]');
        if (таб) {
            localStorage.setItem('quantum_stats_period', таб.dataset.statsPeriod);
            this.paintChronicles(list);
            return;
        }
        if (событие.target.closest('[data-stats-reset]')) {
            if (!window.confirm(this.t('chroniclesResetAsk'))) return;
            localStorage.setItem('analytics_reset_timestamp', String(Date.now()));
            this.paintChronicles(list);
        }
    }

    // Ширина каждой шкалы — её доля. Ставится кодом: см. renderChronicleStats.
    applyStatShares(list) {
        list.querySelectorAll('.qm-stat-bar span[data-share]').forEach(bar => {
            const share = Number(bar.dataset.share);
            bar.style.width = (Number.isFinite(share) ? share : 0) + '%';
        });
    }

    /* Ключ записи для сводки — по id двери, а не по месту (выкладка 185, см. chronicle-stats.js):
       после удаления двери из середины открытия больше не съезжают на соседку. */
    statKeyOf(item) {
        return statKey(item, this.statDoorIds());
    }

    // Id нынешних дверей по местам; у двери без id — пусто (её записи найдутся по месту)
    statDoorIds() {
        return Array.from({ length: this.realities.length }, (_, slot) => this.doorIds[slot] || '');
    }

    // Нынешнее название слота; для старых записей — то, что в них записано
    statNameOf(key, fallback) {
        if (key.indexOf('slot:') === 0) {
            const slot = Number(key.slice(5));
            if (slot >= 0 && slot < this.realities.length) return this.doorDisplayName(slot);
        }
        return fallback || this.t('emptyTrace');
    }

    renderRecentChronicles() {
        const since = Date.now() - 24 * 60 * 60 * 1000;
        const fresh = this.history.filter(item => Number(item.ts) >= since);

        // Тексты человека экранируются: кавычки и символы < > больше не
        // ломают карточку и не могут выполнить разметку.
        const body = fresh.length === 0
            ? `<p class="qm-empty">${this.escapeHtml(this.t('chroniclesNoneDay'))}</p>`
            : fresh.map(item => `
            <div class="chronicle-card">
                <div class="chronicle-date">${this.escapeHtml(item.dateStr)}</div>
                <div class="chronicle-reality">${this.escapeHtml(this.t('akashiAct'))}<br>${this.escapeHtml(this.statNameOf(this.statKeyOf(item), item.reality))}</div>
                <div class="chronicle-trace">${this.escapeHtml(this.t('akashiTrace'))}<br>«${this.escapeHtml(item.trace)}»</div>
            </div>`).join('');

        return `<section class="qm-chron-section">
            <h4 class="qm-chron-head">${this.escapeHtml(this.t('chronicles24h'))}</h4>
            ${body}
        </section>`;
    }

    /* Доля каждой двери за выбранный период.

       В списке стоят все двери, а не только открытые: у двери, которую за период не открывали, своя
       строка и пустая шкала. Длина шкалы — доля этой двери от всех переходов периода.

       ДВЕРИ НА СВОИХ МЕСТАХ И С НОМЕРАМИ (выкладка 185, владелец 27.10.2026): порядок — как в описании
       дверей, от числа открытий не зависит; меняются только шкалы. Пустая дверь (без имени, фото и
       записи), которую не открывали, не показывается. Последняя открытая дверь — зелёным (выкладка 186, было
       красным): её номер, прирост доли «+N%» и шкала — прежняя доля золотом, прирост зелёным. Расчёт — chronicle-stats.js. */
    renderChronicleStats() {
        const { rows, lastKey, beforeTotal } = chronicleRows({
            history: this.history, doorIds: this.statDoorIds(), since: this.statsSince(), before: this.statsBefore()
        });

        const body = rows.map(row => {
            const name = this.statNameOf(row.key, row.fallback);
            // Пустая и ни разу не открытая дверь — не показывается
            if (row.count === 0 && row.slot !== null && !(this.realities[row.slot] || '').trim()
                && name === this.t('doorTitleEmpty')) return '';

            /* Доля едет в data-атрибуте, а не в style: у страницы style-src 'self' без unsafe-inline,
               браузер отбросил бы style="width:…" и шкала стала бы полной. Ширину ставит applyStatShares
               через CSSOM. У последней двери шкала из двух частей: прежняя доля и прирост. */
            const шкала = row.last
                ? `<span data-share="${row.prevShare}"></span><span class="qm-stat-gain" data-share="${row.gain}"></span>`
                : `<span data-share="${row.share}"></span>`;
            const прирост = row.last
                ? ` <b class="qm-stat-delta">+${row.gain}%</b>` : '';
            const номер = row.number !== null ? row.number : '·';
            /* Прошлый период (выкладка 188, в 187 была метка поперёк шкалы — владелец: «перечёркивает»):
               под шкалой тонкая серая полоска той же шкалы — доля двери тогда, и «было N%». Спокойно, без
               красного и зелёного: это наблюдение, а не оценка. Ширину ставит тот же applyStatShares. */
            const прошлая = row.before !== null
                ? `<div class="qm-stat-bar qm-stat-bar-was"><span data-share="${row.before}"></span></div>` : '';
            const было = row.before !== null
                ? ` <span class="qm-stat-before">${this.escapeHtml(this.t('chroniclesWas').replace('{n}', row.before))}</span>` : '';
            return `<div class="qm-stat-row${row.count === 0 ? ' qm-stat-idle' : ''}${row.last ? ' qm-stat-last' : ''}"${row.last
                ? ` title="${this.escapeHtml(this.t('chroniclesLastHint').replace('{n}', row.gain))}"` : ''}>
                <div class="qm-stat-top">
                    <span class="qm-stat-num">${номер}</span>
                    <span class="qm-stat-name">${this.escapeHtml(name)}</span>
                    <span class="qm-stat-count">${row.count} ${this.escapeHtml(this.plural(row.count))} · ${row.share}%${прирост}${было}</span>
                </div>
                <div class="qm-stat-bar">${шкала}</div>
                ${прошлая}
            </div>`;
        }).join('');
        /* Пояснения цветов — под списком (выкладка 188): сначала смотришь на шкалы, потом читаешь, что значат
           цвета; наверху они каждый раз заслоняли сами двери. */
        const пояснение = lastKey
            ? `<p class="qm-stats-legend"><span class="qm-stats-legend-dot"></span>${this.escapeHtml(this.t('chroniclesLastLegend'))}</p>`
            : '';
        /* Строка о прошлом периоде: сколько тогда было открытий — по одному числу видно, весомы ли проценты
           (два открытия — 50% одно; двадцать — 50% десять). Открытий не было — сравнивать не с чем. */
        const месяц = this.statsPeriod() === 'month';
        const прошлое = beforeTotal === null ? ''
            : beforeTotal === 0
                ? `<p class="qm-stats-legend">${this.escapeHtml(this.t(месяц ? 'chroniclesWasNoneMonth' : 'chroniclesWasNoneWeek'))}</p>`
                : `<p class="qm-stats-legend"><span class="qm-stats-legend-was"></span>${this.escapeHtml(this.t(месяц ? 'chroniclesWasLegendMonth' : 'chroniclesWasLegendWeek')
                    .replace('{n}', `${beforeTotal} ${this.plural(beforeTotal)}`))}</p>`;

        const период = this.statsPeriod();
        const таб = (ключ, слово) => `<button type="button" class="qm-stats-tab" data-stats-period="${ключ}"
            aria-pressed="${период === ключ}">${this.escapeHtml(this.t(слово))}</button>`;
        const сброс = this.statsBaseline();
        const сКакого = сброс
            ? `<p class="qm-stats-since">${this.escapeHtml(this.t('chroniclesSince').replace('{date}',
                new Date(сброс).toLocaleString(this.lang === 'en' ? 'en-GB' : this.lang === 'uk' ? 'uk-UA' : 'ru-RU',
                    { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })))}</p>`
            : '';

        return `<section class="qm-chron-section">
            <div class="qm-stats-bar">
                <div class="qm-stats-tabs" role="group">
                    ${таб('week', 'chroniclesWeek')}${таб('month', 'chroniclesMonth')}${таб('all', 'chroniclesAll')}
                </div>
                <button type="button" class="qm-stats-reset" data-stats-reset>${this.escapeHtml(this.t('chroniclesReset'))}</button>
            </div>
            ${сКакого}
            ${body}
            ${пояснение || прошлое ? `<div class="qm-stats-legends">${пояснение}${прошлое}</div>` : ''}
        </section>`;
    }

    /* Склонение числа открытий: русскому и украинскому нужны три формы,
       английскому две — там вторая и третья в словаре совпадают. */
    plural(n) {
        if (this.lang === 'en') return this.t(n === 1 ? 'chroniclesTimesOne' : 'chroniclesTimesMany');

        const hundreds = Math.abs(n) % 100;
        const tens = hundreds % 10;

        if (hundreds > 10 && hundreds < 20) return this.t('chroniclesTimesMany');
        if (tens === 1) return this.t('chroniclesTimesOne');
        if (tens >= 2 && tens <= 4) return this.t('chroniclesTimesFew');
        return this.t('chroniclesTimesMany');
    }

    handleSnooze() {
        if (this.notifications.snooze()) {
            this.updateSnoozeButtonUI();
            /* Откладывание сдвинуло время окна на десять минут — значит,
               сдвинуть надо и системный будильник, иначе он позвонит по
               прежнему сроку, который человек только что отодвинул. */
            planReminders().catch(err => console.warn('[напоминания]', err));
            alert(this.t('snoozeAlertOk'));
        } else {
            alert(this.t('snoozeAlertLimit'));
        }
    }

    updateSnoozeButtonUI() {
        const btn = document.getElementById('btn-snooze');
        if (!btn) return;
        if (this.notifications.canSnooze()) {
            btn.classList.remove('hidden');
            btn.innerText = `${this.t('btnSnooze')} (${3 - this.notifications.snoozeCount}/3)`;
        } else {
            btn.classList.add('hidden');
        }
    }

    showOpportunityModal() {
        const modal = document.getElementById('modal-opportunity');
        if (!modal) return;
        // Счётчик оставшихся отсрочек всегда свежий к моменту показа
        this.updateSnoozeButtonUI();
        modal.classList.remove('hidden');
    }

    hideOpportunityModal() {
        const modal = document.getElementById('modal-opportunity');
        if (modal) modal.classList.add('hidden');
    }

    /* ТАЙМЕР «ДО ВОЗМОЖНОГО СЛЕДУЮЩЕГО ПРЫЖКА» — по часам Наблюдателя (core/observer-clock.js,
       выкладка 148): тот же расчёт, что у плашки, виджетов и таймера в «Режиме будильника».
       Опора цикла — прыжок или прозвучавший назначенный звонок; до назначенного звонка, если
       он раньше окна, таймер считает до него. */
    checkScheduleAndTimer() {
        // Назначенный час — в память таймера; дальше его обновляет каждое чтение и сохранение режима
        loadAlarm().catch(() => null);
        loadQuiet().catch(() => null);   // и тихий час: окно в нём открывается с её концом
        this.scheduleInterval = setInterval(() => {
            const last = parseInt(localStorage.getItem('last_quantum_jump_time') || '0');
            const now = Date.now();
            const часы = observerClock({
                lastJump: last, named: observerNamedHour(), now, setAt: observerNamedSetAt(),
                cooldownMs: CONFIG.timing.jumpCooldownMs, windowMs: CONFIG.timing.opportunityWindowMs,
                quiet: observerQuiet()
            });
            const disp = document.getElementById('s5-cooldown-timer');

            if (часы.phase === 'never') {
                if (disp) disp.innerText = this.t('windowOpen');
                return;
            }

            if (часы.phase === 'cooldown') {
                this.windowTriggered = false;
                if (disp) {
                    disp.innerText = `${this.t('timerPrefix')}${countdownText(часы.next - now)}`;
                    this.updateSnoozeButtonUI();
                }
            } else {
                // Окно возможностей открыто
                const elapsedWindowMs = now - часы.opens;

                if (часы.phase === 'open') {
                    const totalElapsedSec = Math.floor(elapsedWindowMs / 1000);
                    const mins = Math.floor(totalElapsedSec / 60);
                    const secs = totalElapsedSec % 60;

                    const modalTimerVal = document.getElementById('modal-timer-val');
                    if (modalTimerVal) {
                        modalTimerVal.innerText = `${mins}мин ${secs}сек`;
                    }

                    // Кнопка отсрочки теперь живёт во всплывающем окне, и
                    // показывает её showOpportunityModal — прятать нечего
                    if (disp) disp.innerText = this.t('windowOpen');

                    /* Окно и перезвон — один раз на каждое открытие окна, а не на каждый запуск
                       приложения: прошивка закрывает его по нескольку раз за минуту, и человек
                       слышал «окно открыто» снова и снова (владелец 18.10.2026). */
                    const показано = Number(localStorage.getItem('quantum_window_shown')) === часы.opens;
                    if (!this.windowTriggered && !показано) {
                        localStorage.setItem('quantum_window_shown', String(часы.opens));
                        logEvent('◎', { a: часы.opens });
                        this.showOpportunityModal();
                        this.notifications.triggerQuantumWindowNotification();
                    }
                    this.windowTriggered = true;
                } else {
                    // Окно пропущено, цикл сбрасывается
                    localStorage.setItem('last_quantum_jump_time', Date.now().toString());
                    this.windowTriggered = false;
                    this.hideOpportunityModal();
                    // Цикл пошёл заново — следующее окно через 3 часа 33 минуты
                    planReminders().catch(err => console.warn('[напоминания]', err));
                }
            }
        }, 1000);
    }

    showScreen(screenKey) {
        document.querySelectorAll('.qm-screen').forEach(el => el.classList.add('hidden'));

        const timer = document.getElementById('hud-timer');
        const langSwitcher = document.getElementById('lang-switcher-container');

        // Режим погружения: 3D-коридор занимает весь экран, остальные
        // экраны живут внутри карточки раздела «Квант».
        if (this.rootEl && this.rootEl.classList) {
            this.rootEl.classList.toggle('qm-immersive', screenKey === null);
        }

        /* Шестерёнка стоит в шапке постоянно.

           Прежде она жила только на главном экране, и из коридора или с
           экрана выбора попасть в настройку дверей было нельзя — только
           пройдя переход до конца. Теперь настройка открывается откуда
           угодно, а «Отмена» возвращает ровно туда, откуда её позвали. */
        const gear = this.$('btn-gear');
        if (gear) gear.hidden = screenKey === 'screen-setup';

        // Откуда пришли в настройку: null означает коридор
        if (screenKey !== 'screen-setup') this.screenBeforeSetup = screenKey;

        if (screenKey) {
            document.getElementById(screenKey).classList.remove('hidden');
            timer.classList.add('hidden');
            if (langSwitcher) langSwitcher.classList.remove('hidden');
            // Экран показан — только теперь у абзацев есть высота
            this.measureFolds();
        } else {
            timer.classList.remove('hidden');
            if (langSwitcher) langSwitcher.classList.add('hidden');
        }
    }

    // Полная остановка модуля при уходе с раздела
    destroy() {
        this._destroyed = true;

        if (this._raf) cancelAnimationFrame(this._raf);
        if (this._sparkRaf) cancelAnimationFrame(this._sparkRaf);
        clearInterval(this.countdownInterval);
        clearInterval(this.scheduleInterval);
        clearInterval(this.countTimer);
        this._timeouts.forEach(clearTimeout);
        this._timeouts = [];

        if (this._onResize) window.removeEventListener('resize', this._onResize);

        this.stopDoorAudio();
        this.stopRecTimer();
        this.$$('.qm-photo-strip').forEach(strip => this.releasePhotoUrls(strip));
        if (this.recorder) {
            this.recorder.stop().catch(() => {});
            this.recorder = null;
            this.recordingDoorId = null;
        }

        if (this.scene3D) {
            this.scene3D.isRunning = false;
            if (this.scene3D.hand && this.scene3D.hand.parentNode) {
                this.scene3D.hand.parentNode.removeChild(this.scene3D.hand);
            }
            /* ВИДЕОКОНТЕКСТ ОТПУСКАЕМ СРАЗУ (выкладка 191). dispose() освобождает только буферы three.js, а сам
               WebGL-контекст жил, пока его не соберёт сборщик мусора, — то есть неопределённо долго. Каждое
               открытие «Наблюдателя» добавляло по контексту во весь экран; на телефоне (OBLUE TANK 3, 27.10.2026)
               видеопамять кончалась, и новый коридор получал мёртвый контекст: таймер идёт, дверей нет, чёрный экран. */
            const renderer = this.scene3D.renderer;
            this.scene3D.disposing = true;
            if (renderer) {
                renderer.dispose();
                renderer.forceContextLoss();
                renderer.domElement.remove();
            }
            this.scene3D = null;
        }
    }
}
