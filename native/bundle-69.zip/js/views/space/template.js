/* DOM-разметка раздела.

   Часть раздела «Квант» — вторая вкладка «Пространство вариантов».
   Модуль изолирован: кроме этой папки и двух строк в app.js он ничего
   в Ежедневнике не трогает.

   id менять нельзя — на них завязаны обработчики в app.js и scene.js. */

export const TEMPLATE = [
    /* --- Выход из раздела -----------------------------------------------
       Раздел занимает весь экран и перекрывает меню Ежедневника, поэтому
       нужен собственный выход. Крестик приглушён и не тянет на себя
       внимание, но всегда на месте. */
    '<button type="button" id="btn-space-close" class="qm-close">×</button>',

    /* --- Переключатель языков (скрывается на время 3D-коридора) -------
       Одна кнопка с текущим языком, по нажатию — список остальных.
       Раздел занимает весь экран и перекрывает кнопку языка Ежедневника,
       поэтому своя здесь обязательна. Список наполняет app.js. */
    '<div id="lang-switcher-container" class="lang-switcher">',
    /* Шестерёнка открывает настройку реальностей. Показывается только на
       главном экране; позже уйдёт под права администратора. */
    '    <button type="button" id="btn-gear" class="qm-gear"></button>',
    '    <button type="button" id="qm-lang-btn" class="qm-lang-current"',
    '            aria-haspopup="true" aria-expanded="false">',
    '        <span id="qm-lang-label">\u{1F1F7}\u{1F1FA} Рус</span>',
    '        <span class="qm-lang-caret" aria-hidden="true"></span>',
    '    </button>',
    '    <div id="qm-lang-menu" class="qm-lang-menu" hidden></div>',
    '</div>',

    /* --- Слои 3D-сцены и золотых песчинок ----------------------------- */
    '<div id="three-canvas"></div>',
    '<canvas id="sand-canvas"></canvas>',

    /* --- Оверлей отсчёта 1-2-3 ---------------------------------------- */
    '<div id="countdown-overlay" class="countdown-overlay hidden">',
    '    <div id="countdown-num" class="countdown-num">1</div>',
    '</div>',

    /* --- Плавное затемнение перехода ---------------------------------- */
    '<div id="blackout-screen" class="blackout-overlay hidden"></div>',

    /* --- Модальное окно «Окно возможностей открыто» -------------------- */
    '<div id="modal-opportunity" class="modal-overlay hidden">',
    '    <div class="modal-card">',
    '        <div class="modal-clock-icon">',
    '            <div class="glowing-blue-circle"><span class="clock-icon">\u{1F552}</span></div>',
    '        </div>',
    '        <h2 id="modal-title" class="modal-title" data-i18n="modalTitle">Окно возможностей открыто</h2>',
    '        <p class="modal-sub" data-i18n="modalSubtitle"></p>',
    '        <div class="modal-timer-box">',
    '            <span data-i18n="modalElapsedPrefix">прошло </span><span id="modal-timer-val">0мин 0сек</span>',
    '        </div>',
    '        <p class="modal-warning" data-i18n="modalWarning"></p>',
    '        <button id="btn-modal-start" class="btn-gold qm-block">',
    '            <span class="gold-cut" data-i18n="modalBtnStart">Войти в суперпозицию</span>',
    '        </button>',

    /* Отсрочка живёт здесь, а не в хрониках: откладывать есть смысл в тот
       миг, когда окно открылось и человек занят, — а не после перехода,
       когда откладывать уже нечего. Надпись ставит updateSnoozeButtonUI:
       в ней счётчик оставшихся отсрочек. */
    '        <button type="button" id="btn-snooze" class="btn-snooze qm-block hidden"></button>',
    '    </div>',
    '</div>',

    /* --- Верхний таймер квантового окна -------------------------------- */
    '<div id="hud-timer" class="hud-timer-container hidden">',
    '    <div class="hud-timer-badge"><span id="hud-timer-val">33.3</span>s</div>',
    '    <div id="txt-s2-sub" class="hud-timer-sub" data-i18n="screen2Instruction"></div>',
    '</div>',

    /* --- ЭКРАН 1: титульная страница раздела --------------------------- */
    '<div id="screen-1" class="qm-screen">',
    '    <div class="metaverse-title-top" data-i18n="metaverseTitle">Моя метавселенная</div>',
    '    <div id="header-metaverse" class="metaverse-header">',
    '        <div class="flower-orbit-container">',
    '            <svg class="flower-svg" viewBox="0 0 200 200" aria-hidden="true">',
    '                <circle cx="100" cy="100" r="90" fill="none" stroke="currentColor" stroke-width="1.5" opacity="0.35"/>',
    '                <circle cx="100" cy="100" r="35" fill="none" stroke="currentColor" stroke-width="1.2" opacity="0.7"/>',
    '                <circle cx="100" cy="65" r="35" fill="none" stroke="currentColor" stroke-width="1.2" opacity="0.7"/>',
    '                <circle cx="100" cy="135" r="35" fill="none" stroke="currentColor" stroke-width="1.2" opacity="0.7"/>',
    '                <circle cx="130.3" cy="82.5" r="35" fill="none" stroke="currentColor" stroke-width="1.2" opacity="0.7"/>',
    '                <circle cx="69.7" cy="82.5" r="35" fill="none" stroke="currentColor" stroke-width="1.2" opacity="0.7"/>',
    '                <circle cx="130.3" cy="117.5" r="35" fill="none" stroke="currentColor" stroke-width="1.2" opacity="0.7"/>',
    '                <circle cx="69.7" cy="117.5" r="35" fill="none" stroke="currentColor" stroke-width="1.2" opacity="0.7"/>',
    '            </svg>',
    '            <div class="quantum-particle outer-quantum"></div>',
    '            <div class="quantum-particle inner-quantum" id="iq1"></div>',
    '            <div class="quantum-particle inner-quantum" id="iq2"></div>',
    '        </div>',
    '    </div>',
    '    <h1 class="qm-hero-title" data-i18n="title1">Пространство вариантов</h1>',
    '    <div class="qm-hero-rule"></div>',
    '    <div class="qm-hero-actions">',
    '        <button id="btn-start-app" class="btn-gold">',
    '            <span class="gold-cut" data-i18n="btnStart">Войти в суперпозицию</span>',
    '        </button>',
    '        <a href="#" id="btn-open-settings" class="btn-link" data-i18n="btnSettings">Изменить варианты реальностей</a>',
    '    </div>',
    '</div>',

    /* --- ЭКРАН НАСТРОЕК: двери и намерения ----------------------------- */
    '<div id="screen-setup" class="qm-screen hidden">',
    '    <div class="card-panel">',
    '        <div class="qm-eyebrow" data-i18n="multiverse">Мультивселенная</div>',
    '        <h2 class="qm-title-md" data-i18n="setupTitle">Настройка Реальностей</h2>',
    '        <p class="qm-sub" data-i18n="setupSub"></p>',
    /* Подпись тянется на всю свободную ширину, выбор — компактный
       квадратик справа. */
    '        <div class="doors-count-selector">',
    '            <label class="doors-count-label" for="doors-count-select" data-i18n="doorsCount">Количество дверей:</label>',
    '            <select id="doors-count-select" class="doors-count-pick">',
    '                <option value="2">2</option>',
    '                <option value="3">3</option>',
    '                <option value="4">4</option>',
    '                <option value="5">5</option>',
    '                <option value="6">6</option>',
    '                <option value="7" selected>7</option>',
    '            </select>',
    '        </div>',
    '        <div id="doors-inputs-container" class="inputs-scroll-area"></div>',
    '        <button id="btn-save-setup" class="btn-gold qm-block">',
    '            <span class="gold-cut" data-i18n="btnSave">Сохранить и войти</span>',
    '        </button>',
    '        <button id="btn-cancel-setup" class="btn-link qm-block" data-i18n="btnCancel">Отмена</button>',
    '    </div>',
    '</div>',

    /* --- ЭКРАН 3: настройка реальности после выбора двери --------------- */
    '<div id="screen-3" class="qm-screen hidden">',
    '    <div class="card-panel text-center">',
    '        <p id="txt-s3-sub" class="qm-sub" data-i18n="screen3Subtitle"></p>',
    '        <h2 id="txt-s3-title" class="qm-title-lg" data-i18n="screen3MainTitle">Настройка реальности</h2>',
    '        <div id="txt-s3-chosen-reality" class="chosen-reality-box-clean"></div>',

    /* Содержимое выбранной двери: её снимки. Запись слышна правой
       половиной составной кнопки ниже. */
    '        <div id="s3-door-media" class="qm-s3-media" hidden></div>',
    '        <p class="qm-speed-title" data-i18n="screen3SpeedTitle"></p>',
    /* Две скорости стоят рядом, в один ряд на всю ширину: прежде они
       лежали одна под другой двумя длинными полосами и забивали экран.
       Подписи оставлены короткими — «Быстрый переход» и «Глубокое
       погружение»; пояснения в скобках ушли, их место под кнопками
       занимает сама инструкция.

       «Рекомендуем» не висит постоянно: оно показывается только когда
       выбрано глубокое погружение, и не мозолит глаза всё время. */
    '        <div class="speed-tabs-container">',
    '            <button type="button" class="speed-tab active" data-speed="1">',
    '                <span class="gold-cut" data-i18n="speedOption1Btn">Быстрый переход</span>',
    '            </button>',
    '            <button type="button" class="speed-tab" data-speed="2">',
    '                <span class="gold-cut" data-i18n="speedOption2Btn">Глубокое погружение</span>',
    '                <span class="badge-rec" data-i18n="speedBadge">Рекомендуем</span>',
    '            </button>',
    '        </div>',
    '        <div id="speed-instruction-text" class="speed-instruction-box"></div>',
    '        <p id="txt-s3-audio-warn" class="qm-audio-warn" hidden></p>',

    /* Золотая капсула: смайлик, пластина «Закрой глаза», круг «Play».

       Смайлик — не кнопка, а лицо всей капсулы: он закрывает глаза, когда
       палец или курсор оказывается на любой её части, и открывает, когда
       уходит. Нажатие на любую половину утапливает капсулу целиком. */
    '        <div class="qm-act" id="qm-act">',
    /* Лицо нарисовано, а не взято эмодзи: эмодзи приносит свой кружок и
       свой цвет, а кружок здесь золотой, из той же пластины, что
       капсула. Поэтому по золоту идут только черты — бровки, глаза,
       щёки и улыбка. Узлы декоративные, нажатий не ловят. */
    '            <span class="qm-act-face" aria-hidden="true">',
    '                <i class="qm-brow qm-brow-l"></i><i class="qm-brow qm-brow-r"></i>',
    '                <i class="qm-eye qm-eye-l"></i><i class="qm-eye qm-eye-r"></i>',
    '                <i class="qm-cheek qm-cheek-l"></i><i class="qm-cheek qm-cheek-r"></i>',
    '                <i class="qm-mouth"></i>',
    '            </span>',
    '            <button type="button" id="btn-s3" class="qm-act-main">',
    '                <span class="gold-cut" data-i18n="screen3Btn">Закрой глаза</span>',
    '            </button>',
    '            <button type="button" id="btn-s3-play" class="qm-act-play qm-play-idle">',
    '                <span class="qm-play-glyph"></span>',
    '            </button>',
    '        </div>',
    '    </div>',
    '</div>',

    /* --- ЭКРАН 4: Дневник Наблюдателя ---------------------------------- */
    '<div id="screen-4" class="qm-screen hidden">',
    '    <div class="card-panel qm-akasha">',
    '        <p id="txt-s4-top" class="gold-notice-box" data-i18n="screen4Top"></p>',
    '        <h2 id="txt-s4-title" class="qm-title-md" data-i18n="screen4Title">Дневник Наблюдателя</h2>',
    '        <p id="txt-s4-sub" class="qm-sub" data-i18n="screen4Subtitle"></p>',
    '        <textarea id="input-s4-diary" rows="7" data-i18n="screen4Placeholder"></textarea>',

    /* Гримуар Акаши: кнопка-фолиант, из которой при нажатии вылетает
       вихрь золотых и синих искр. Холст лежит поверх и кликов не ловит. */
    '        <div class="qm-tome-wrap">',
    '            <canvas id="qm-tome-sparks" class="qm-tome-sparks" aria-hidden="true"></canvas>',
    '            <button type="button" id="btn-s4-save" class="qm-tome">',
    '                <span class="qm-tome-edge" aria-hidden="true"></span>',
    '                <span class="qm-tome-text gold-cut" id="qm-tome-text" data-i18n="screen4Btn">Активировать в Хрониках Акаши</span>',
    '                <span class="qm-tome-flare" aria-hidden="true"></span>',
    '            </button>',
    '        </div>',
    '    </div>',
    '</div>',

    /* --- ЭКРАН 5: Хроники Акаши ---------------------------------------- */
    '<div id="screen-5" class="qm-screen hidden">',
    '    <div class="qm-chronicles-wrap">',
    '        <div class="qm-cooldown-panel">',
    '            <div id="s5-cooldown-timer"></div>',
    '        </div>',
    '        <div class="qm-chronicles-head">',
    '            <h3 id="txt-s5-title" data-i18n="screen5Title"></h3>',
    '            <button id="btn-edit-from-s5" class="btn-link-small" data-i18n="btnEditFromS5"></button>',
    '        </div>',
    '        <p id="txt-s5-sub" data-i18n="screen5Subtitle"></p>',
    '        <div id="chronicles-list"></div>',
    '    </div>',
    '</div>'
].join('\n');
