// Работа без сети. Сначала сеть, кэш — только запасной: так телефон не застревает
// на старой версии приложения. Запросы к серверу Планера не кэшируются.
const RELEASE = 174;
const CACHE = `planner-v${RELEASE}`;
const SHELL = [
  /* manifest.webmanifest отсюда убран вместе с самим файлом: сайт больше
     не предлагает поставить себя ярлыком-приложением — установка одна, и
     это настоящее приложение (см. пояснение в index.html). Строку нельзя
     было просто оставить: addAll падает целиком, если хоть один файл в
     списке отдаёт 404, и тогда перестал бы работать весь офлайн. */
  './', 'index.html', 'css/game-tokens.css', 'css/app.css',
  'icons/icon.svg', 'icons/icon-192.png', 'icons/icon-512.png',
  /* Манифест для компьютера и его скрипт. Манифеста для телефона в
     странице по-прежнему нет — этот подключается только настольным
     браузерам (js/pc-install.js). Оба файла обязаны существовать:
     addAll падает целиком, если хоть один отдаёт 404. */
  'manifest-pc.webmanifest', 'js/pc-install.js', 'js/core/pc-install-rules.js',
  'js/app.js', 'js/ios-home.js', 'manifest.webmanifest', 'js/store.js', 'js/db.js', 'js/sync.js', 'js/auth.js', 'js/config.js', 'js/wheel.js', 'js/errors.js', 'js/update.js', 'js/password-eye.js',
  'js/reminder-plan.js', 'js/support.js', 'js/views/cabinet-editor.js', 'css/cabinet-editor.css',
  // Окно «Установить виджет» (раздел 9.21): модуль, его стили и чистые правила с значками
  'js/widgets-ui.js', 'css/widgets.css', 'js/core/widgets.js', 'js/core/widget-icons.js',
  // Окно виджета на компьютере и общая отрисовка виджета (выкладка 150)
  'widget.html', 'js/widget-desktop.js', 'css/widget-desktop.css', 'js/core/widget-html.js',
  'js/views/wheel.js', 'js/views/day.js', 'js/views/quantum.js', 'js/views/quantum-sound.js', 'js/views/quantum-slit.js', 'js/views/money.js', 'js/profile.js',
  'css/space.css',
  'js/views/space/index.js', 'js/views/space/app.js', 'js/views/space/config.js',
  'js/views/space/audio.js', 'js/views/space/photos.js',
  'js/views/space/notifications.js', 'js/views/space/scene.js', 'js/views/space/template.js',
  'js/vendor/three.min.js',
  'admin.html', 'css/admin.css', 'js/admin.js',
  'js/core/net.js', 'js/core/media-box.js', 'js/core/access-controller.js', 'js/core/reminders.js', 'js/core/reminder-rules.js', 'js/core/observer-clock.js', 'js/core/live-update.js',
  'js/core/money.js', 'js/core/media.js', 'js/core/calendar.js', 'js/core/dates.js', 'js/core/calc.js', 'js/core/session.js', 'js/core/diary.js', 'js/core/i18n.js', 'js/core/quantum.js'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(caches.keys()
    .then(keys => Promise.all(keys.filter(k => k.startsWith('planner-') && k !== CACHE).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});

/* СВОИ ФАЙЛЫ БЕРЁМ С ПРОВЕРКОЙ У СЕРВЕРА.

   Обычный fetch отдаёт файл из браузерного кэша, не спрашивая сервер. GitHub
   Pages держит статику десять минут — и всё это время браузер мог вернуть
   новый admin.html вместе со старым admin.js. Разметка от новой выкладки,
   код от старой: кнопка есть, обработчика нет, экран не открывается. Так и
   случилось после выкладки 27.

   cache: 'no-cache' не значит «не кэшировать»: файл по-прежнему хранится, но
   перед выдачей браузер спрашивает сервер отпечатком (ETag). Не изменился —
   приходит пустой ответ 304 и файл берётся с диска. Лишнего трафика это почти
   не добавляет, зато смеси версий больше не бывает.

   Нет сети — ответ придёт из запаса, как и раньше. */
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== location.origin) return;
  /* Запрос пересобираем по адресу, а не копированием: у перехода по ссылке
     режим navigate, и копия с другими настройками кэша для него недопустима —
     браузер отверг бы её. По адресу же получается обычный запрос, ответ на
     который подходит и для перехода. */
  const fresh = new Request(event.request.url, {
    cache: 'no-cache', credentials: 'same-origin', headers: event.request.headers
  });
  event.respondWith(fetch(fresh)
    .then(res => {
      if (res.ok) {
        const copy = res.clone();
        caches.open(CACHE).then(c => c.put(event.request, copy));
      }
      return res;
    })
    .catch(() => caches.match(event.request, { ignoreSearch: true })));
});
