/* Оболочка приложения: разделы, меню, язык, вход.
   Сами экраны живут в js/views/, общее состояние — в js/store.js. */

import { clearAll, getMeta, setMeta } from './db.js';
import { initSync, syncNow, deleteAccount } from './sync.js';
import { requestAccess, createFirstAdmin, login as doLogin, hasSession, logout, logoutAndClear, fetchMe, changeOwnPassword, saveAvatar } from './auth.js';
import { shrinkPhoto, paintAvatar, watchInstall, installed } from './profile.js';
import { API_BASE, serverAlive } from './config.js';
import {
  state, t, save, reload, onChange, changed, $, h, svgIcon, ICONS,
  activeSectors, sectorName, seedSectors, round
} from './store.js';
import { LANGUAGES, pickLanguage, isLanguage } from './core/i18n.js';
import { watchErrors } from './errors.js';
import { initUpdate } from './update.js';
import { initPasswordEyes } from './password-eye.js';
import { initWheel, renderWheelView, openAssess } from './views/wheel.js';
import { initDay, renderDay } from './views/day.js';
import { initQuantum, renderQuantum, loadQuantum, quietChanged } from './views/quantum.js';
import { initSpace, syncSpace, openPart as openQuantumPart } from './views/space/index.js';
import { initSlit } from './views/quantum-slit.js';
import { ACCESS_ENABLED, AccessController } from './core/access-controller.js';
import { cancelAll as cancelAllReminders, isNative, openAlarmSettings } from './core/reminders.js';
import {
  initReminders, planReminders, loadQuiet, saveQuiet, normalizeQuiet,
  loadAlarm, saveAlarm, alarmState
} from './reminder-plan.js';
import { minutesOfDay, normalizeAlarm } from './core/reminder-rules.js';
import { shouldSeed } from './core/sectors.js';
import { markStartedOk, checkForUpdate } from './core/live-update.js';
import { renderMoney, openEntry, saveEntry, fillCategorySelect } from './views/money.js';
import { weekWheel } from './core/calc.js';
import { mondayOf, todayKey } from './core/dates.js';

/* Порядок разделов — порядок дня, а не порядок разработки.

   Квант стоит первым и открывается при запуске: это то, ради чего человек
   берёт телефон девять раз в день, и ждать отклика он должен сразу. Колесо
   ушло в конец: это итог недели, его смотрят раз, а не между делом. */
const SECTIONS = [
  { id: 'quantum', icon: ICONS.quantum, title: 'quantum.title', label: 'nav.quantum' },
  { id: 'day', icon: ICONS.day, title: 'day.title', label: 'nav.day' },
  { id: 'money', icon: ICONS.money, title: 'money.title', label: 'nav.money' },
  { id: 'wheel', icon: ICONS.wheel, title: 'wheel.title', label: 'nav.wheel' }
];

const STATUS_KEY = {
  local: 'sync.local', syncing: 'sync.syncing', synced: 'sync.synced',
  offline: 'sync.offline', error: 'sync.error', idle: null
};

/* ---------- Язык ---------- */

// Подписи, вшитые в разметку: меняются целиком при смене языка
//
// РАЗДЕЛ «ПРОСТРАНСТВО ВАРИАНТОВ» ОБХОДИМ СТОРОНОЙ.
//
// У него свой словарь (js/views/space/config.js) и свои ключи. Этот обход
// шёл по всему документу, включая поддерево раздела, а здешний t() таких
// ключей не знает и по правилу возвращает сам ключ. Поэтому после любой
// смены языка — и после каждого входа, где applyLanguage() зовётся по
// умолчанию, — на экранах раздела вместо текста проступали METAVERSETITLE,
// title1, btnStart, btnSettings, setupTitle, doorsCount, btnSave,
// screen2Instruction. Подписи дверей оставались целыми только потому, что
// они живут в placeholder, а не в textContent.
//
// Поддерево раздела переводит его собственный applyLang(); syncSpace()
// зовёт его следом за сменой языка, так что ни одна подпись не теряется.
function applyLanguage() {
  document.documentElement.lang = state.language;
  document.querySelectorAll('[data-i18n]').forEach(el => {
    if (el.closest('.qm-root')) return;
    el.textContent = t(el.dataset.i18n);
  });
  const current = LANGUAGES.find(l => l.code === state.language);
  $('langLabel').textContent = `${current.flag} ${current.label}`;
  renderLangMenu();
  renderNav();
  render();
}

function renderLangMenu() {
  $('langMenu').replaceChildren(...LANGUAGES.map(l => h('button', {
    type: 'button',
    'aria-pressed': String(l.code === state.language),
    onclick: () => setLanguage(l.code)
  }, h('span', { text: `${l.flag} ${l.name}` }), h('span', { class: 'code', text: l.label }))));
}

function setLanguage(code) {
  if (!isLanguage(code)) return;
  state.language = code;
  closeLangMenu();
  applyLanguage();
  // Запоминаем в фоне: экран не должен ждать записи в базу — она может
  // задержаться за идущей синхронизацией, и язык переключался бы с паузой
  setMeta('language', code).catch(() => {});
}

const closeLangMenu = () => {
  $('langMenu').hidden = true;
  $('langBtn').setAttribute('aria-expanded', 'false');
};

/* ---------- Разделы и меню ---------- */

async function go(section) {
  state.view = section;
  closeDrawer();
  render();
  // День квантового модуля тянем, только когда в него зашли и его ещё нет
  if (section === 'quantum' && !state.quantum) {
    await loadQuantum();
    render();
    renderNav();            // счётчик непрожитых моментов
  }
}

function render() {
  // До первой загрузки данных рисовать нечего: applyLanguage() зовёт render()
  // ещё на экране входа, когда index пуст
  if (!state.index) return;
  const current = SECTIONS.find(s => s.id === state.view) || SECTIONS[0];
  $('screenTitle').textContent = t(current.title);
  for (const section of SECTIONS) {
    $(`view${section.id[0].toUpperCase()}${section.id.slice(1)}`).hidden = section.id !== state.view;
  }
  document.querySelectorAll('#bottomNav button').forEach(b => {
    if (b.dataset.section === state.view) b.setAttribute('aria-current', 'page');
    else b.removeAttribute('aria-current');
  });
  $('drawerMain').querySelectorAll('button').forEach(b => {
    if (b.dataset.section === state.view) b.setAttribute('aria-current', 'page');
    else b.removeAttribute('aria-current');
  });

  if (state.view === 'wheel') renderWheelView();
  if (state.view === 'day') renderDay();
  if (state.view === 'quantum') renderQuantum();
  syncSpace();                 // вторая вкладка «Кванта»: гаснет вне раздела
  if (state.view === 'money') renderMoney();
  renderDrawerSpheres();
}

/* Счётчик у раздела — то, что ждёт человека: непрожитые моменты,
   невыполненные задачи. Ноль не показываем: пустая метка только шумит. */
function sectionBadge(id) {
  if (!state.index) return null;
  if (id === 'day') {
    const left = state.data.tasks.filter(x => !x.deletedAt && x.date === state.day && !x.done).length;
    return left || null;
  }
  // Выключенные моменты не ждут человека — их нет и в счётчике
  if (id === 'quantum') return state.quantum ? state.quantum.moments.filter(m => !m.doneAt && !m.offAt).length || null : null;
  return null;
}

function navButton(section, iconSize) {
  const badge = sectionBadge(section.id);
  return h('button', {
    type: 'button', dataset: { section: section.id }, onclick: () => go(section.id)
  },
    svgIcon(section.icon, iconSize),
    h('span', { text: t(section.label) }),
    badge ? h('span', { class: 'count', text: String(badge) }) : null);
}

/* Кнопка «Профиль» в нижнем меню — вместо гамбургера в шапке.

   Гамбургер стоял в левом верхнем углу и открывал меню, в котором
   половина пунктов и так лежит в нижнем ряду: разделы. Остальное —
   кабинет человека, настройки, выход — и есть профиль, поэтому кнопка
   названа по тому, что за ней на самом деле.

   Пятой в ряду, а не первой: четыре раздела идут в своём порядке дня,
   и профиль к ним не относится. На широком экране нижнее меню скрыто
   целиком, а меню и так стоит слева постоянно — кнопка там не нужна и
   не появляется. */
function drawerButton() {
  return h('button', {
    type: 'button', dataset: { section: 'profile' }, onclick: openDrawer
  }, svgIcon(ICONS.profile, 22), h('span', { text: t('nav.profile') }));
}

function renderNav() {
  $('bottomNav').replaceChildren(...SECTIONS.map(s => navButton(s, 22)), drawerButton());
  $('drawerMain').replaceChildren(...SECTIONS.map(s => navButton(s, 19)));

  // Служебное прижато вниз за разделителем — приём из того же меню.
  // Кабинет администратора виден только тому, у кого есть на это право:
  // это не отдельное приложение, а лишние вкладки в том же кабинете
  const service = [
    h('button', {
      type: 'button',
      onclick: () => { closeDrawer(); openSettings(); $('settingsDialog').showModal(); }
    }, svgIcon(ICONS.settings, 19), h('span', { text: t('nav.settings') }))
  ];
  if (state.me?.role === 'admin') {
    service.push(h('a', { href: 'admin.html' }, svgIcon(ICONS.admin, 19), h('span', { text: t('nav.admin') })));
  }
  $('drawerService').replaceChildren(...service);
}

function renderDrawerSpheres() {
  if (!state.index || $('spheresToggle').getAttribute('aria-expanded') === 'false') {
    if (state.index) $('drawerSpheres').replaceChildren();
    return;
  }
  const rows = weekWheel(state.index, mondayOf(todayKey()), todayKey());
  $('drawerSpheres').replaceChildren(...rows.map(row => h('button', {
    type: 'button', onclick: () => go('wheel')
  },
    h('span', { class: `dot s${row.sector.slot}` }),
    h('span', { text: sectorName(row.sector) }),
    h('span', { class: 'trailing', text: row.pct === null ? '—' : `${round(row.pct)}%` }))));
}

/* Порог «широкого экрана» один на весь проект и совпадает с медиазапросом
   в app.css. Когда он жил в двух местах, они разошлись: вёрстка считала
   экран широким, а код — узким, и панель оставалась спрятанной. */
const WIDE = '(min-width: 768px)';
const isWide = () => window.matchMedia(WIDE).matches;

const openDrawer = () => { $('drawer').hidden = false; $('drawerBack').hidden = false; };
const closeDrawer = () => {
  if (isWide()) return;              // на широком экране панель всегда видна
  $('drawer').hidden = true;
  $('drawerBack').hidden = true;
};

/* Раздел «Деньги» живёт в views/money.js — там же правила счёта и голос */

/* ---------- Настройки ---------- */

function openSettings() {
  const count = activeSectors().length;
  $('countButtons').querySelectorAll('button').forEach(b =>
    b.setAttribute('aria-pressed', String(Number(b.dataset.count) === count)));
  $('sectorEditList').replaceChildren(...activeSectors().map(s => h('li', { class: 'edit-row' },
    h('span', { class: `dot s${s.slot}` }),
    h('input', {
      value: s.name, maxLength: 40, placeholder: t('common.sectorN', { n: s.slot }),
      'aria-label': sectorName(s),
      onchange: e => save('sectors', [{ ...s, name: e.target.value.trim().slice(0, 40) }])
    }),
    h('label', {}, h('input', {
      type: 'checkbox', checked: s.paused,
      onchange: e => save('sectors', [{ ...s, paused: e.target.checked }])
    }), t('settings.notNow')))));

  // Свой пароль можно сменить только когда есть сервер и вход выполнен
  if (!API_BASE) {
    $('accountInfo').textContent = t('settings.serverOff');
    $('changePassword').hidden = true;
  } else if (state.me) {
    $('accountInfo').textContent = t('settings.loggedIn', { name: state.me.displayName, email: state.me.email });
    $('changePassword').hidden = false;
  } else {
    $('accountInfo').textContent = t('settings.noLink');
    $('changePassword').hidden = true;
  }
}

/* ---------- Вход ---------- */

const LOGIN_ERRORS = {
  invalid_credentials: 'auth.wrongCredentials',
  pending_approval: 'auth.pending',
  blocked: 'auth.blocked'
};

function showGate() {
  $('appRoot').hidden = true;
  $('authGate').hidden = false;
  // Не ждём ответа: экран входа должен появиться сразу, а настройка —
  // переключить его, когда сервер скажет, что администраторов ещё нет
  setupMode();
}
function hideGate() {
  $('authGate').hidden = true;
  $('appRoot').hidden = false;
  if (isWide()) { $('drawer').hidden = false; $('drawerBack').hidden = true; }
}

function gateTab(which) {
  const loginActive = which === 'login';
  $('gateTabLogin').setAttribute('aria-selected', String(loginActive));
  $('gateTabRequest').setAttribute('aria-selected', String(!loginActive));
  $('loginForm').hidden = !loginActive;
  $('requestForm').hidden = loginActive;
}

/* Система ещё не настроена — показываем не вход, а заведение первого кабинета.
   Вход и заявка в этот момент бессмысленны: входить некому, а заявку
   рассматривать некому. Как только администратор появился, сервер отвечает
   «не нужно», и экран навсегда становится обычным. */
async function setupMode() {
  if (!API_BASE) return false;
  let needed = false;
  try {
    const res = await fetch(`${API_BASE}/api/setup`, { cache: 'no-store' });
    if (res.ok) needed = (await res.json()).needed === true;
  } catch {
    // Сервер промолчал — показываем обычный вход, а не экран настройки:
    // предлагать завести администратора там, где некому ответить, незачем
    return false;
  }
  $('gateTabs').hidden = needed;
  $('setupForm').hidden = !needed;
  if (needed) { $('loginForm').hidden = true; $('requestForm').hidden = true; }
  return needed;
}

/* ---------- Запуск ---------- */

/* Кто вошёл — в шапке панели. Заполняется после start() на обоих путях:
   и когда сессия уже была, и когда человек только что ввёл пароль. */
function renderUser() {
  if (!state.me) return;
  const account = String(state.me.accountNo ?? 0).padStart(9, '0');
  paintAvatar($('userInitial'), state.me.avatar, state.me.displayName);
  $('userName').textContent = state.me.displayName;
  // Номер кабинета девятью цифрами — его можно продиктовать администратору
  $('userAccount').textContent = account;

  paintAvatar($('profilePhoto'), state.me.avatar, state.me.displayName);
  $('profileName').textContent = state.me.displayName;
  $('profileAccount').textContent = account;
  $('changePassword').hidden = false;
  $('photoClear').hidden = !state.me.avatar;
}

function showPasswordError(text) {
  const msg = $('passwordMsg');
  msg.textContent = text;
  msg.className = 'gate-msg is-error';
  $('passwordDialog').returnValue = '';
  $('passwordDialog').showModal();
}

/* ---------- Тихий час ---------- */

/** Что сейчас стоит в полях окна. */
function quietFromForm() {
  return {
    on: $('quietOn').checked,
    from: $('quietFrom').value,
    until: $('quietUntil').value
  };
}

/* Итог человеческими словами, под полями.

   Нужен не для красоты. Промежуток через полночь читается неочевидно: «с
   21:00 до 6:00» — это девять часов тишины, и в них попадает завтрашнее
   утро, а не сегодняшнее. Строка сразу показывает, сколько именно часов
   человек себе выключил, и ошибку видно до сохранения, а не через сутки
   по пропущенному напоминанию. */
function showQuietSummary(quiet) {
  const box = $('quietSummary');
  const value = normalizeQuiet(quiet);

  if (!value.on) { box.textContent = t('quiet.offNote'); return; }

  const from = minutesOfDay(value.from);
  const until = minutesOfDay(value.until);

  if (from === until) { box.textContent = t('quiet.sameNote'); return; }

  const длина = from > until ? (24 * 60 - from + until) : (until - from);
  box.textContent = t('quiet.lasts', {
    hours: Math.floor(длина / 60),
    minutes: длина % 60
  });
}

/* ---------- Режим будильника ---------- */

/** Что сейчас стоит в галочках окна. */
function alarmFromForm() {
  return {
    on: $('alarmOn').checked,
    moments: $('alarmMoments').checked
  };
}

/* Итог человеческими словами, под галочками.

   Двух галочек мало, чтобы человек понял, что именно он включил: «режим
   будильника» звучит как «теперь всё звонит», а это не так. Строка
   называет вслух, что будет звонить, а что останется плашкой, — и
   ошибку видно до сохранения, а не ночью. */
function showAlarmSummary(alarm) {
  const box = $('alarmSummary');
  const value = normalizeAlarm(alarm);

  if (!value.on) { box.textContent = t('alarm.offNote'); return; }
  box.textContent = value.moments ? t('alarm.bothNote') : t('alarm.onNote');
}

/* Почему будильник может не зазвонить.

   Две разные беды, и чинятся они по-разному, поэтому и говорятся
   по-разному:

     нет плагина — приложение собрано раньше, чем он появился. Настройкой
     не чинится, нужен новый файл приложения;
     нет разрешения на полноэкранные напоминания — чинится настройкой
     телефона, и туда можно отвести прямо отсюда (Android 14 и новее;
     на Android 13 и старше такой настройки нет, и кнопки не будет).

   Молчать нельзя ни о той, ни о другой: человек включил бы настройку и
   ждал звонка, которого не будет. */
async function showAlarmTrouble() {
  const поле = $('alarmTrouble');
  const кнопка = $('alarmAllow');
  поле.hidden = true;
  кнопка.hidden = true;

  // В браузере напоминаний не бывает вовсе — об этом говорит своя строка
  if (!isNative()) return;

  const состояние = await alarmState();

  if (!состояние.plugin) {
    поле.textContent = t('alarm.noPlugin');
    поле.hidden = false;
    return;
  }

  if (!состояние.fullScreen) {
    поле.textContent = t('alarm.noFullScreen');
    поле.hidden = false;
    кнопка.hidden = !состояние.askable;
  }
}

let syncStarted = false;

async function start() {
  await reload();
  /* Сервер не отвечает — синхронизацию не заводим вовсе. Иначе она сама
     обнаружит отсутствие входа и покажет экран входа, который в этом
     случае бесполезен: войти всё равно некуда. */
  if (!syncStarted && !state.serverDown) {
    syncStarted = true;
    initSync({
      status: s => { $('syncStatus').textContent = STATUS_KEY[s] ? t(STATUS_KEY[s]) : ''; },
      data: async () => { await reload(); changed(); },
      authLost: showGate
    });
  } else if (syncStarted) {
    // После повторного входа start() зовётся снова, а обработчики событий
    // синхронизации вешать второй раз нельзя
    syncNow();
  }

  if (API_BASE && !state.serverDown) {
    state.me = await fetchMe();
    renderUser();
    await loadQuantum();     // счётчик моментов нужен сразу, на любом экране
    renderNav();
  }

  /* СИСТЕМНЫЕ НАПОМИНАНИЯ.

     Ставим расписание здесь, а не раньше: моменты дня приходят с сервера,
     и до loadQuantum ставить было бы нечего. Окну возможностей сервер не
     нужен, но и торопиться с ним некуда — всё расписание ставится одним
     заходом.

     В браузере эта строка молчит: системных напоминаний там не бывает, и
     кодом это не чинится. Работает только в собранном приложении.

     По нажатию на уведомление открываем ту вкладку, о которой оно: окно
     возможностей живёт в «Пространстве вариантов», моменты — в соседней.
     Иначе человек попадал бы туда, где был в прошлый раз. */
  initReminders(key => {
    go('quantum');
    openQuantumPart(key === 'quantum-window' ? 'space' : 'moments');
  });

  /* СФЕРЫ ПО УМОЛЧАНИЮ — ТОЛЬКО КОГДА ИЗВЕСТНО, ЧТО У ЗАПИСИ ИХ НЕТ.

     Прежде здесь стояла проверка «нет сфер — создать», и она и задваивала
     сферы. Устройство, на котором сфер нет, — это не то же самое, что
     учётная запись, у которой их нет: так выглядит и свежая установка, и
     очищенный телефон, и приложение, впервые открытое при недоступном
     сервере. В каждом из этих случаев девять сфер создавались заново, со
     своими случайными id, и при следующей синхронизации складывались с
     теми, что уже лежали на сервере. На экране получалось восемнадцать
     сфер вместо девяти.

     Теперь решение принимает shouldSeed (core/sectors.js), и ему нужен
     ответ на вопрос «а что на сервере». Этот ответ даёт только удачная
     синхронизация: syncNow возвращает true лишь на том единственном пути,
     где обмен с сервером состоялся.

     Сервер недоступен — не засеваем вовсе. Пустое колесо объясняет себя
     само (renderNotice в views/wheel.js), и это честнее, чем девять
     заготовок, которые завтра придётся сводить с настоящими. Потерять мы
     этим ничего не можем: регистрация закрытая, учётную запись выдаёт
     сервер, и пользоваться приложением, ни разу до него не добравшись,
     всё равно нельзя. */
  if (!state.index.sectors.length) {
    const синхронизировано = state.serverDown ? false : Boolean(await syncNow());
    if (синхронизировано) await reload();

    if (shouldSeed({
      signedIn: await hasSession(),
      accountKnown: синхронизировано,
      sectorCount: state.index.sectors.length
    })) {
      await seedSectors();
    }
  }
  render();

  /* В собранном приложении service worker не нужен и даже вреден: файлы и
     так лежат на телефоне, а его запас мог бы заслонить свежий пакет,
     пришедший по воздуху. В браузере он по-прежнему главный работник
     офлайна. */
  const inApp = Boolean(window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function'
    && window.Capacitor.isNativePlatform());

  if (!inApp && 'serviceWorker' in navigator
      && (location.protocol === 'https:' || location.hostname === 'localhost')) {
    navigator.serviceWorker.register('./sw.js').catch(err => console.warn('[sw]', err.message));
  }
}

async function boot() {
  watchErrors();

  /* Раздел «Пространство вариантов» занимает весь экран и перекрывает
     кнопку языка, поэтому у него своя. Переключить язык везде может только
     Ежедневник — раздел лишь просит об этом событием. */
  document.addEventListener('qm-lang-change', e => setLanguage(e.detail));

  /* Приложение поднялось — отчитываемся сразу, пока не истекли десять
     секунд, после которых плагин откатил бы выкладку назад. И тут же
     смотрим, не вышло ли новое: в браузере обе строчки ничего не делают. */
  markStartedOk();
  checkForUpdate();

  // Повернули телефон или растянули окно — панель должна стать той, какой надо
  window.matchMedia(WIDE).addEventListener('change', e => {
    $('drawer').hidden = !e.matches;
    $('drawerBack').hidden = true;
  });
  state.language = pickLanguage(await getMeta('language').catch(() => null), navigator.languages || []);

  initWheel();
  initDay();
  initQuantum();
  initSpace();
  initSlit();

  // Ежедневная проверка прав и «рубильник». Пока ACCESS_ENABLED = false,
  // этот блок не делает ничего: ни запросов, ни блокировок.
  // Включать только после проверки, что сервер отвечает всем устройствам —
  // иначе через сутки без связи заблокируются сразу все.
  if (ACCESS_ENABLED) {
    new AccessController({
      apiBase: API_BASE,
      getToken: () => getMeta('token'),
      // Закрытое приложение не должно будить человека
      cancelAlarms: cancelAllReminders
    }).start();
  }
  onChange(render);

  // Меню, язык, настройки
  $('drawerBack').addEventListener('click', closeDrawer);
  $('langBtn').addEventListener('click', () => {
    const open = $('langMenu').hidden;
    $('langMenu').hidden = !open;
    $('langBtn').setAttribute('aria-expanded', String(open));
  });
  document.addEventListener('click', e => {
    if (!e.target.closest('.lang-wrap')) closeLangMenu();
  });
  document.addEventListener('keydown', e => {
    if (e.key !== 'Escape') return;
    closeLangMenu();
    closeDrawer();
  });

  // Группа сфер: сворачивание и быстрый переход к настройке — действия
  // прямо в заголовке группы, как в том меню
  $('spheresToggle').addEventListener('click', () => {
    const open = $('spheresToggle').getAttribute('aria-expanded') === 'true';
    $('spheresToggle').setAttribute('aria-expanded', String(!open));
    renderDrawerSpheres();
  });
  $('spheresSettings').addEventListener('click', () => {
    closeDrawer();
    openSettings();
    $('settingsDialog').showModal();
  });

  /* ТИХИЙ ЧАС.

     Открываем окно, заполнив поля тем, что сохранено. Сохраняем только по
     кнопке «Сохранить»: «Отмена» и крестик должны оставлять прежнее
     время, иначе человек, заглянувший посмотреть, молча поменял бы себе
     настройку. */
  $('quietHours').addEventListener('click', async () => {
    const quiet = await loadQuiet();
    $('quietOn').checked = quiet.on;
    $('quietFrom').value = quiet.from;
    $('quietUntil').value = quiet.until;
    showQuietSummary(quiet);
    // В браузере напоминаний не бывает — говорим об этом прямо в окне
    $('quietBrowserNote').hidden = isNative();
    $('quietDialog').returnValue = '';
    $('quietDialog').showModal();
  });

  // Подсказка живая: человек видит итог, ещё не нажав «Сохранить»
  for (const id of ['quietOn', 'quietFrom', 'quietUntil']) {
    $(id).addEventListener('change', () => showQuietSummary(quietFromForm()));
  }

  $('quietDialog').addEventListener('close', async () => {
    if ($('quietDialog').returnValue !== 'save') return;
    await saveQuiet(quietFromForm());
    /* Тихий час вырезает своё время из окон, поэтому девять моментов
       после его правки другие. Пересобираем день сразу: человек закрыл
       окно и должен увидеть новые времена, а не прежние. */
    await quietChanged();
  });

  /* РЕЖИМ БУДИЛЬНИКА.

     Тот же порядок, что у тихого часа: открываем окно, заполнив
     галочки сохранённым, и сохраняем только по кнопке «Сохранить». */
  $('alarmMode').addEventListener('click', async () => {
    const alarm = await loadAlarm();
    $('alarmOn').checked = alarm.on;
    $('alarmMoments').checked = alarm.moments;
    showAlarmSummary(alarm);
    $('alarmBrowserNote').hidden = isNative();
    await showAlarmTrouble();
    $('alarmDialog').returnValue = '';
    $('alarmDialog').showModal();
  });

  for (const id of ['alarmOn', 'alarmMoments']) {
    $(id).addEventListener('change', () => showAlarmSummary(alarmFromForm()));
  }

  /* Отвести за разрешением. Окно не закрываем: человек вернётся из
     настроек телефона и должен увидеть ту же настройку, а не пустой
     профиль. Строку о беде перечитываем — разрешение могло появиться. */
  $('alarmAllow').addEventListener('click', async () => {
    await openAlarmSettings();
  });

  $('alarmDialog').addEventListener('close', async () => {
    if ($('alarmDialog').returnValue !== 'save') return;
    await saveAlarm(alarmFromForm());
  });

  // Свой пароль человек меняет сам; администратор выдаёт только первый
  $('changePassword').addEventListener('click', () => {
    $('passwordForm').reset();
    $('passwordMsg').textContent = '';
    $('passwordMsg').className = 'gate-msg';
    $('settingsDialog').close();
    $('passwordDialog').returnValue = '';
    $('passwordDialog').showModal();
  });

  $('passwordDialog').addEventListener('close', async () => {
    if ($('passwordDialog').returnValue !== 'save') return;
    const f = $('passwordForm').elements;
    const next = f.newPassword.value;
    const msg = $('passwordMsg');
    if (next !== f.repeatPassword.value) { showPasswordError(t('password.mismatch')); return; }
    if (next.length < 8) { showPasswordError(t('password.tooShort')); return; }
    try {
      await changeOwnPassword(f.currentPassword.value, next);
      alert(t('password.saved'));
    } catch (err) {
      showPasswordError(t(err.code === 'wrong_current_password' ? 'password.wrongCurrent' : 'password.failed'));
    }
  });

  $('openAssess').addEventListener('click', openAssess);
  $('countButtons').addEventListener('click', async e => {
    const n = Number(e.target.dataset.count);
    if (!n) return;
    const changedSectors = state.index.sectors
      .filter(s => s.active !== (s.position <= n))
      .map(s => ({ ...s, active: s.position <= n }));
    if (changedSectors.length) await save('sectors', changedSectors);
    openSettings();
  });
  $('deleteData').addEventListener('click', async () => {
    if (!confirm(t('settings.deleteConfirm'))) return;
    try {
      await deleteAccount();
    } catch {
      alert(t('auth.noNetwork'));
      return;
    }
    await clearAll();
    location.reload();
  });
  /* ---------- Деньги ---------- */

  // Список категорий заполняется один раз и обновляется при смене языка
  fillCategorySelect($('moneyForm').elements.category);
  $('moneyBack').addEventListener('click', () => $('moneyDialog').close());
  $('moneyDialog').addEventListener('close', async () => {
    if ($('moneyDialog').returnValue === 'save') await saveEntry();
  });

  /* ---------- Профиль ---------- */

  $('drawerUser').addEventListener('click', () => { closeDrawer(); $('profileDialog').showModal(); });
  $('profileBack').addEventListener('click', () => $('profileDialog').close());

  /* Выход без вопросов: он ничего не теряет. Записи остаются на устройстве,
     закрывается только вход. Спрашивать подтверждение у действия, которое
     легко отменить обратным входом, — значит пугать на ровном месте. */
  $('profileLogout').addEventListener('click', async () => {
    await logout();
    location.reload();
  });

  // Фотография: выбрали файл — сжали на устройстве — отправили строкой
  $('photoPick').addEventListener('click', () => $('photoFile').click());
  $('photoFile').addEventListener('change', async e => {
    const file = e.target.files?.[0];
    e.target.value = '';                       // чтобы тот же файл можно было выбрать снова
    if (!file) return;
    const msg = $('photoMsg');
    msg.className = 'gate-msg';
    msg.textContent = t('profile.photoWorking');
    try {
      const small = await shrinkPhoto(file);
      state.me.avatar = await saveAvatar(small);
      renderUser();
      msg.className = 'gate-msg is-ok';
      msg.textContent = t('profile.photoSaved');
    } catch (err) {
      msg.className = 'gate-msg is-error';
      msg.textContent = t(err.status === 413 || err.status === 400 ? 'profile.photoTooBig' : 'profile.photoFailed');
    }
    setTimeout(() => { msg.textContent = ''; }, 4000);
  });
  $('photoClear').addEventListener('click', async () => {
    try {
      state.me.avatar = await saveAvatar('');
      renderUser();
    } catch { /* не убралась — остаётся как была */ }
  });

  // Кнопка установки появляется, только когда браузер готов её предложить
  watchInstall($('installApp'));

  // Вход и заявка
  $('gateTabLogin').addEventListener('click', () => gateTab('login'));
  $('gateTabRequest').addEventListener('click', () => gateTab('request'));
  $('loginForm').addEventListener('submit', async e => {
    e.preventDefault();
    const msg = $('loginMsg');
    msg.className = 'gate-msg';
    msg.textContent = '';
    const f = e.target.elements;
    try {
      await doLogin(f.login.value, f.password.value);
      hideGate();
      await start();
    } catch (err) {
      msg.className = 'gate-msg is-error';
      msg.textContent = t(LOGIN_ERRORS[err.code] || 'auth.noNetwork');
    }
  });
  /* Пароль придумывает устройство, а не человек. Показываем его открытым:
     записать можно только то, что видно, а восстановить этот пароль потом
     будет некому — самостоятельного сброса в системе нет. */
  $('setupGenerate').addEventListener('click', () => {
    const alphabet = '23456789ABCDEFGHJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz';
    const bytes = crypto.getRandomValues(new Uint8Array(16));
    const made = Array.from(bytes, b => alphabet[b % alphabet.length]).join('');
    const f = $('setupForm').elements;
    f.password.value = made;
    f.password2.value = made;
    f.password.type = 'text';
    f.password2.type = 'text';
    const msg = $('setupMsg');
    msg.className = 'gate-msg is-ok';
    msg.textContent = t('auth.passwordMade');
  });

  $('setupForm').addEventListener('submit', async e => {
    e.preventDefault();
    const msg = $('setupMsg');
    msg.className = 'gate-msg';
    msg.textContent = '';
    const f = e.target.elements;
    // Опечатку в пароле, который нигде больше не записан и который некому
    // восстановить, человек обнаружил бы уже запертым снаружи
    if (f.password.value !== f.password2.value) {
      msg.className = 'gate-msg is-error';
      msg.textContent = t('auth.passwordsDiffer');
      return;
    }
    try {
      await createFirstAdmin({
        displayName: f.displayName.value, email: f.email.value, password: f.password.value
      });
      // Кабинет заведён — сразу входим им же, чтобы не набирать пароль дважды
      await doLogin(f.email.value, f.password.value);
      hideGate();
      await start();
    } catch (err) {
      msg.className = 'gate-msg is-error';
      msg.textContent = t(err.status === 409 ? 'auth.setupDone'
        : err.status === 400 ? 'auth.checkFields' : 'auth.requestFailed');
    }
  });
  $('requestForm').addEventListener('submit', async e => {
    e.preventDefault();
    const msg = $('requestMsg');
    msg.className = 'gate-msg';
    const f = e.target.elements;
    try {
      await requestAccess({
        displayName: f.displayName.value, email: f.email.value,
        phone: f.phone.value, telegramId: f.telegramId.value
      });
      msg.className = 'gate-msg is-ok';
      msg.textContent = t('auth.requestSent');
      e.target.reset();
    } catch (err) {
      msg.className = 'gate-msg is-error';
      msg.textContent = t(err.status === 400 ? 'auth.checkFields' : 'auth.requestFailed');
    }
  });

  applyLanguage();
  initUpdate();
  initPasswordEyes();

  /* Сервер ещё не поднят — не встречаем человека экраном входа, который
     всё равно не работает. Приложение живёт на устройстве и говорит об
     этом строкой состояния. Как только сервер ответит, вход и синхронизация
     включатся сами, без новой выкладки. */
  if (API_BASE && !(await serverAlive())) {
    state.serverDown = true;
    hideGate();
    await start();
    $('syncStatus').textContent = t('sync.local');
    return;
  }

  if (API_BASE && !(await hasSession())) { showGate(); return; }
  hideGate();
  await start();
}

boot();
